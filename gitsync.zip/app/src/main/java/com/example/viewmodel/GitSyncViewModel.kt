package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChangeType
import com.example.data.DeviceAuthStatus
import com.example.data.FolderCandidate
import com.example.data.GitHubAccount
import com.example.data.GitHubRepo
import com.example.data.InstallationStatus
import com.example.data.Project
import com.example.data.ProjectFileItem
import com.example.data.SyncActivityItem
import com.example.data.SyncStatus
import com.example.data.local.ProjectEntity
import com.example.data.local.RecentFolderEntity
import com.example.data.local.TokenStore
import com.example.data.remote.GitHubException
import com.example.data.repository.GITHUB_APP_INSTALL_URL
import com.example.data.repository.GitHubAuthRepository
import com.example.data.repository.GitHubRepoRepository
import com.example.data.repository.GitSyncRepository
import com.example.data.repository.ProjectFileRepository
import com.example.data.repository.ScannedProject
import com.example.ui.navigation.AppScreen
import com.example.ui.navigation.BottomTab
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** GitHub App client ID (public -- safe to embed; no Client Secret is ever used here). */
private const val GITHUB_APP_CLIENT_ID = "Iv23liBov1aMzInMTttP"

enum class RepoSelectionMode {
    CREATE_NEW,
    USE_EXISTING
}

data class GitSyncUiState(
    val currentScreen: AppScreen = AppScreen.Welcome,
    val currentTab: BottomTab = BottomTab.HOME,
    val account: GitHubAccount = GitHubAccount(),
    val projects: List<Project> = emptyList(),
    val activities: List<SyncActivityItem> = emptyList(),
    val projectSearchQuery: String = "",
    val repoSearchQuery: String = "",

    // Device Flow state
    val authStatus: DeviceAuthStatus = DeviceAuthStatus.DISCONNECTED,
    val deviceUserCode: String? = null,
    val deviceVerificationUri: String? = null,

    // GitHub App installation state — separate from authorization (authStatus/account above).
    val installationStatus: InstallationStatus = InstallationStatus.UNKNOWN,
    val isCheckingInstallation: Boolean = false,

    // Wizard State
    val selectedFolder: FolderCandidate? = null,
    val isScanningFolder: Boolean = false,
    val recentFolders: List<FolderCandidate> = emptyList(),
    val previewFiles: List<ProjectFileItem> = emptyList(),
    val wizardProjectName: String = "",
    val wizardCommitMessage: String = "Initial project upload",
    val wizardBranch: String = "main",
    val wizardRepoMode: RepoSelectionMode = RepoSelectionMode.CREATE_NEW,
    val wizardNewRepoName: String = "",
    val wizardNewRepoDesc: String = "",
    val wizardNewRepoPrivate: Boolean = true,
    val isCreatingRepo: Boolean = false,
    val wizardSelectedExistingRepo: GitHubRepo? = null,
    val remoteRepos: List<GitHubRepo> = emptyList(),
    val isLoadingRepos: Boolean = false,

    // Upload & Push Progress State
    val isUploading: Boolean = false,
    val uploadProgressPercent: Float = 0f,
    val uploadedFilesCount: Int = 0,
    val totalFilesCount: Int = 0,
    val uploadedSizeMb: Double = 0.0,
    val totalSizeMb: Double = 0.0,
    val uploadStageIndex: Int = 0, // 0: Selected, 1: Prepared, 2: Staged, 3: Uploading, 4: Complete
    val activePushRepoFullName: String = "",

    // Push Changes Flow State
    val activeProjectId: String = "",
    val isCheckingChanges: Boolean = false,
    val pushChangesCommitMessage: String = "Update project",
    val pendingDiffAdded: Int = 0,
    val pendingDiffModified: Int = 0,
    val pendingDiffDeleted: Int = 0,
    val pendingChangedFileItems: List<ProjectFileItem> = emptyList(),
    val showReviewChangesSheet: Boolean = false,

    // Dialog Flags
    val showDisconnectDialog: Boolean = false,
    val showRemoveProjectDialog: Boolean = false,
    val projectPendingRemoval: Project? = null,
    val showWhyGitHubAccessDialog: Boolean = false,
    val showBrowseFoldersSheet: Boolean = false,

    // Settings
    val defaultBranch: String = "main",
    val defaultRepoPrivate: Boolean = true,
    val appearance: String = "System default"
)

class GitSyncViewModel(application: Application) : AndroidViewModel(application) {

    private val tokenStore = TokenStore(application)
    private val authRepository = GitHubAuthRepository(application, tokenStore, GITHUB_APP_CLIENT_ID)
    private val repoRepository = GitHubRepoRepository(application, tokenStore)
    private val syncRepository = GitSyncRepository(application, tokenStore)

    private val _uiState = MutableStateFlow(GitSyncUiState())
    val uiState: StateFlow<GitSyncUiState> = _uiState.asStateFlow()

    private var uploadJob: Job? = null
    private var deviceFlowJob: Job? = null
    private var pendingRetryAction: (() -> Unit)? = null

    // Not part of UI state: the last real folder scan, kept in memory so the
    // upload/push step can read files without re-scanning from a Composable.
    private var currentScannedProject: ScannedProject? = null
    private var currentTreeUri: Uri? = null

    init {
        viewModelScope.launch {
            syncRepository.observeProjects().collect { entities ->
                _uiState.update { it.copy(projects = entities.map { e -> e.toProject() }) }
            }
        }
        viewModelScope.launch {
            syncRepository.observeRecentFolders().collect { entities ->
                _uiState.update { it.copy(recentFolders = entities.map { e -> e.toFolderCandidate() }) }
            }
        }
        if (authRepository.isConnected()) {
            _uiState.update { it.copy(account = GitHubAccount(isConnected = true), currentScreen = AppScreen.Home) }
            refreshAccount()
        }
    }

    private fun refreshAccount() {
        viewModelScope.launch {
            try {
                val info = authRepository.fetchAuthenticatedUser()
                val repoCount = try { repoRepository.listAllRepos().size } catch (e: Exception) { 0 }
                _uiState.update {
                    it.copy(
                        account = GitHubAccount(
                            username = info.login,
                            displayName = info.displayName,
                            isConnected = true,
                            avatarInitials = info.login.take(1).uppercase(),
                            repoCount = repoCount
                        )
                    )
                }
                checkInstallationStatus()
            } catch (e: GitHubException.Unauthorized) {
                authRepository.disconnect()
                _uiState.update { it.copy(account = GitHubAccount(), installationStatus = InstallationStatus.UNKNOWN) }
            } catch (e: Exception) {
                // Keep the optimistic connected state; details refresh next time.
            }
        }
    }

    /**
     * Re-checks GitHub App installation state via GitHub's real API (never
     * just trusting a locally cached boolean). Safe to call repeatedly —
     * e.g. from "Check again" or when the app resumes from the browser.
     */
    fun checkInstallationStatus() {
        if (!_uiState.value.account.isConnected) return
        viewModelScope.launch {
            _uiState.update { it.copy(isCheckingInstallation = true) }
            val result = authRepository.checkInstallation()
            _uiState.update {
                it.copy(isCheckingInstallation = false, installationStatus = result.status)
            }
        }
    }

    /** Called from the Activity's lifecycle when the app resumes (e.g. back from the browser). */
    fun onAppResumed() {
        val state = _uiState.value
        if (state.account.isConnected && state.installationStatus != InstallationStatus.INSTALLED) {
            checkInstallationStatus()
        }
    }

    fun openInstallGitHubApp(): String = GITHUB_APP_INSTALL_URL

    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun selectTab(tab: BottomTab) {
        _uiState.update { current ->
            val targetScreen = when (tab) {
                BottomTab.HOME -> AppScreen.Home
                BottomTab.PROJECTS -> AppScreen.Projects
                BottomTab.ACTIVITY -> AppScreen.Activity
                BottomTab.SETTINGS -> AppScreen.Settings
            }
            current.copy(currentTab = tab, currentScreen = targetScreen)
        }
    }

    private fun showError(message: String, title: String = "Something went wrong", retry: (() -> Unit)? = null) {
        pendingRetryAction = retry
        _uiState.update {
            it.copy(currentScreen = AppScreen.ErrorState(message = message, title = title, canRetry = retry != null))
        }
    }

    fun retryFromError() {
        val action = pendingRetryAction
        pendingRetryAction = null
        if (action != null) action() else selectTab(BottomTab.HOME)
    }

    /**
     * GitHub App permission/installation problems (missing Contents: write,
     * missing Administration: write, App not installed) get a friendlier,
     * actionable message instead of just the raw GitHub error — with the
     * real GitHub detail kept as supporting text underneath, and "Try
     * again" routed back to Connect GitHub (where the Install/Update card
     * lives) rather than blindly repeating the failed call.
     */
    private fun showPermissionRequiredError(detail: GitHubException.PermissionDenied, forCreateRepo: Boolean) {
        _uiState.update {
            it.copy(isCreatingRepo = false, isUploading = false, isCheckingChanges = false)
        }
        val friendlySummary = if (forCreateRepo) {
            "GitSync Mobile needs permission to manage repository settings and create repositories on this GitHub account."
        } else {
            "GitSync Mobile needs Contents: write permission to upload and update files."
        }
        showError(
            message = "$friendlySummary\n\n${detail.message}",
            title = "GitHub permission required"
        ) {
            navigateTo(AppScreen.ConnectGitHub)
            checkInstallationStatus()
        }
    }

    // ---------------- GitHub Connection (OAuth Device Flow) ----------------

    fun connectGitHub() {
        deviceFlowJob?.cancel()
        _uiState.update {
            it.copy(authStatus = DeviceAuthStatus.REQUESTING_CODE, deviceUserCode = null, deviceVerificationUri = null)
        }
        deviceFlowJob = viewModelScope.launch {
            try {
                val codeResponse = authRepository.requestDeviceCode()
                _uiState.update {
                    it.copy(
                        authStatus = DeviceAuthStatus.AWAITING_USER,
                        deviceUserCode = codeResponse.userCode,
                        deviceVerificationUri = codeResponse.verificationUri
                    )
                }
                authRepository.pollForAccessToken(codeResponse.deviceCode, codeResponse.interval)
                _uiState.update { it.copy(authStatus = DeviceAuthStatus.EXCHANGING_TOKEN) }

                val info = authRepository.fetchAuthenticatedUser()

                // A different GitHub account than last time connected here —
                // never mix one account's projects/repos into another's view.
                if (authRepository.didAccountChange(info.login)) {
                    syncRepository.clearAllLocalProjectData()
                }
                authRepository.rememberUsername(info.login)

                val repoCount = try { repoRepository.listAllRepos().size } catch (e: Exception) { 0 }
                val installationResult = authRepository.checkInstallation()
                _uiState.update {
                    it.copy(
                        authStatus = DeviceAuthStatus.DISCONNECTED,
                        deviceUserCode = null,
                        deviceVerificationUri = null,
                        account = GitHubAccount(
                            username = info.login,
                            displayName = info.displayName,
                            isConnected = true,
                            avatarInitials = info.login.take(1).uppercase(),
                            repoCount = repoCount
                        ),
                        installationStatus = installationResult.status,
                        currentTab = BottomTab.HOME,
                        // Authorization succeeding is not the same as the App
                        // being installed — stay on this same Connect screen
                        // (which now shows the Install card) until it is.
                        currentScreen = if (installationResult.status == InstallationStatus.INSTALLED) {
                            AppScreen.Home
                        } else {
                            AppScreen.ConnectGitHub
                        }
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(authStatus = DeviceAuthStatus.DISCONNECTED, deviceUserCode = null, deviceVerificationUri = null)
                }
                showError(e.message ?: "Couldn't connect to GitHub.", title = "Couldn't connect to GitHub") { connectGitHub() }
            }
        }
    }

    fun cancelConnecting() {
        deviceFlowJob?.cancel()
        _uiState.update {
            it.copy(authStatus = DeviceAuthStatus.DISCONNECTED, deviceUserCode = null, deviceVerificationUri = null)
        }
    }

    fun requestDisconnect() {
        _uiState.update { it.copy(showDisconnectDialog = true) }
    }

    fun dismissDisconnectDialog() {
        _uiState.update { it.copy(showDisconnectDialog = false) }
    }

    fun confirmDisconnect() {
        authRepository.disconnect()
        _uiState.update {
            it.copy(
                account = GitHubAccount(),
                installationStatus = InstallationStatus.UNKNOWN,
                showDisconnectDialog = false,
                currentScreen = AppScreen.ConnectGitHub
            )
        }
    }

    // ---------------- Project Selection & Wizard ----------------

    fun openBrowseFolders() {
        _uiState.update { it.copy(showBrowseFoldersSheet = true) }
    }

    fun dismissBrowseFolders() {
        _uiState.update { it.copy(showBrowseFoldersSheet = false) }
    }

    /** Called after the system folder picker (SAF) returns a folder. */
    fun onFolderPicked(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningFolder = true) }
            try {
                syncRepository.fileRepository.persistPermission(uri)
                val scanned = syncRepository.fileRepository.scanProject(uri)
                currentScannedProject = scanned
                currentTreeUri = uri
                syncRepository.recordRecentFolder(uri, scanned)

                val candidate = FolderCandidate(
                    name = scanned.rootDisplayName,
                    relativePath = scanned.rootDisplayName,
                    fullPath = uri.toString(),
                    fileCount = scanned.files.size,
                    sizeMb = ProjectFileRepository.bytesToMb(scanned.totalSizeBytes)
                )
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        selectedFolder = candidate,
                        wizardProjectName = candidate.name,
                        wizardNewRepoName = sanitizeRepoName(candidate.name),
                        totalFilesCount = candidate.fileCount,
                        totalSizeMb = candidate.sizeMb,
                        previewFiles = scanned.previewItems,
                        showBrowseFoldersSheet = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isScanningFolder = false, showBrowseFoldersSheet = false) }
                showError(e.message ?: "Couldn't read that folder.", title = "Couldn't read folder") { onFolderPicked(uri) }
            }
        }
    }

    /** Re-selecting a previously used folder from the Browse Folders sheet re-scans it for fresh data. */
    fun selectFolder(folder: FolderCandidate) {
        onFolderPicked(Uri.parse(folder.fullPath))
    }

    fun updateWizardCommitMessage(message: String) {
        _uiState.update { it.copy(wizardCommitMessage = message) }
    }

    fun setRepoSelectionMode(mode: RepoSelectionMode) {
        _uiState.update { it.copy(wizardRepoMode = mode) }
    }

    fun updateNewRepoFields(name: String, desc: String, isPrivate: Boolean) {
        _uiState.update {
            it.copy(
                wizardNewRepoName = name,
                wizardNewRepoDesc = desc,
                wizardNewRepoPrivate = isPrivate
            )
        }
    }

    fun openExistingRepoScreen() {
        _uiState.update { it.copy(currentScreen = AppScreen.ExistingRepo, isLoadingRepos = true) }
        viewModelScope.launch {
            try {
                val repos = repoRepository.listAllRepos().filter { it.canPush }
                _uiState.update {
                    it.copy(
                        isLoadingRepos = false,
                        remoteRepos = repos.map { r ->
                            GitHubRepo(
                                id = r.id.toString(),
                                name = r.name,
                                owner = r.ownerLogin,
                                fullName = r.fullName,
                                isPrivate = r.isPrivate,
                                description = r.description,
                                defaultBranch = r.defaultBranch
                            )
                        }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoadingRepos = false) }
                showError(e.message ?: "Couldn't load your repositories.", title = "Couldn't load repositories") { openExistingRepoScreen() }
            }
        }
    }

    fun selectExistingRepo(repo: GitHubRepo) {
        _uiState.update { it.copy(wizardSelectedExistingRepo = repo, wizardBranch = repo.defaultBranch) }
    }

    fun createRepository() {
        val name = _uiState.value.wizardNewRepoName.trim()
        if (name.isBlank()) return
        _uiState.update { it.copy(isCreatingRepo = true) }
        viewModelScope.launch {
            try {
                val remote = repoRepository.createRepository(
                    name = name,
                    description = _uiState.value.wizardNewRepoDesc,
                    isPrivate = _uiState.value.wizardNewRepoPrivate
                )
                val repoModel = GitHubRepo(
                    id = remote.id.toString(),
                    name = remote.name,
                    owner = remote.ownerLogin,
                    fullName = remote.fullName,
                    isPrivate = remote.isPrivate,
                    description = remote.description,
                    defaultBranch = remote.defaultBranch
                )
                _uiState.update {
                    it.copy(
                        isCreatingRepo = false,
                        wizardSelectedExistingRepo = repoModel,
                        wizardNewRepoName = remote.name,
                        wizardBranch = remote.defaultBranch,
                        currentScreen = AppScreen.ReviewPush
                    )
                }
            } catch (e: GitHubException.PermissionDenied) {
                showPermissionRequiredError(e, forCreateRepo = true)
            } catch (e: Exception) {
                _uiState.update { it.copy(isCreatingRepo = false) }
                showError(e.message ?: "Couldn't create the repository.", title = "Couldn't create repository") { createRepository() }
            }
        }
    }

    // ---------------- Initial Upload ----------------

    fun startUploadFlow() {
        val scanned = currentScannedProject
        val treeUri = currentTreeUri
        val targetRepo = _uiState.value.wizardSelectedExistingRepo
        if (scanned == null || treeUri == null || targetRepo == null) {
            showError(
                "Your project folder isn't ready. Please select it again.",
                title = "Couldn't start upload"
            ) { navigateTo(AppScreen.SelectProject) }
            return
        }

        val projectId = "proj_${System.currentTimeMillis()}"
        val commitMessage = _uiState.value.wizardCommitMessage.ifBlank { "Initial project upload" }
        val branch = _uiState.value.wizardBranch

        uploadJob?.cancel()
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.UploadProgress,
                isUploading = true,
                uploadStageIndex = 1,
                uploadedFilesCount = 0,
                totalFilesCount = scanned.files.size,
                totalSizeMb = ProjectFileRepository.bytesToMb(scanned.totalSizeBytes),
                uploadProgressPercent = 0f,
                activePushRepoFullName = targetRepo.fullName
            )
        }

        uploadJob = viewModelScope.launch {
            try {
                _uiState.update { it.copy(uploadStageIndex = 2) }
                val outcome = syncRepository.pushInitial(
                    projectId = projectId,
                    scanned = scanned,
                    owner = targetRepo.owner,
                    repo = targetRepo.name,
                    branch = branch,
                    commitMessage = commitMessage
                ) { uploaded, total, uploadedBytes, totalBytes ->
                    _uiState.update {
                        it.copy(
                            uploadStageIndex = 3,
                            uploadedFilesCount = uploaded,
                            totalFilesCount = total,
                            uploadProgressPercent = if (total > 0) uploaded.toFloat() / total else 1f,
                            uploadedSizeMb = ProjectFileRepository.bytesToMb(uploadedBytes),
                            totalSizeMb = ProjectFileRepository.bytesToMb(totalBytes)
                        )
                    }
                }
                _uiState.update { it.copy(uploadStageIndex = 4, uploadProgressPercent = 1f) }

                val entity = ProjectEntity(
                    id = projectId,
                    name = _uiState.value.wizardProjectName,
                    folderUri = treeUri.toString(),
                    ownerLogin = targetRepo.owner,
                    repoName = targetRepo.name,
                    repoFullName = targetRepo.fullName,
                    branch = branch,
                    isPrivate = targetRepo.isPrivate,
                    description = targetRepo.description,
                    lastPushedAtMillis = System.currentTimeMillis(),
                    lastCommitSha = outcome.commitSha,
                    lastCommitMessage = commitMessage,
                    lastFileCount = scanned.files.size,
                    lastSizeBytes = scanned.totalSizeBytes
                )
                syncRepository.saveProject(entity)

                val newActivity = SyncActivityItem(
                    id = "act_${System.currentTimeMillis()}",
                    projectName = entity.name,
                    actionText = "Pushed project",
                    timeText = "Just now",
                    statusText = "Synced",
                    commitMessage = commitMessage,
                    commitHash = outcome.commitSha.take(7)
                )
                _uiState.update {
                    it.copy(
                        isUploading = false,
                        activities = listOf(newActivity) + it.activities,
                        currentScreen = AppScreen.PushSuccess,
                        activeProjectId = projectId
                    )
                }
            } catch (e: GitHubException.PermissionDenied) {
                showPermissionRequiredError(e, forCreateRepo = false)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(isUploading = false) }
                showError(e.message ?: "The upload failed. Please try again.", title = "Couldn't push to GitHub") { startUploadFlow() }
            }
        }
    }

    // ---------------- Push Changes Flow ----------------

    fun openPushChanges(projectId: String) {
        _uiState.update { it.copy(activeProjectId = projectId, isCheckingChanges = true) }
        viewModelScope.launch {
            try {
                val entity = syncRepository.getProject(projectId) ?: throw IllegalStateException("This project is no longer available.")
                val treeUri = Uri.parse(entity.folderUri)
                val scanned = syncRepository.fileRepository.scanProject(treeUri)
                currentScannedProject = scanned
                currentTreeUri = treeUri

                val diff = syncRepository.getDiffSummary(projectId, scanned)
                val changedItems = diff.addedPaths.map { it.toProjectFileItem(ChangeType.ADDED) } +
                    diff.modifiedPaths.map { it.toProjectFileItem(ChangeType.MODIFIED) } +
                    diff.deletedPaths.map { it.toProjectFileItem(ChangeType.DELETED) }

                _uiState.update {
                    it.copy(
                        isCheckingChanges = false,
                        pushChangesCommitMessage = "Update project",
                        pendingDiffAdded = diff.addedPaths.size,
                        pendingDiffModified = diff.modifiedPaths.size,
                        pendingDiffDeleted = diff.deletedPaths.size,
                        pendingChangedFileItems = changedItems,
                        currentScreen = if (diff.hasChanges) AppScreen.PushChanges(projectId) else AppScreen.NoChanges(projectId)
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isCheckingChanges = false) }
                showError(e.message ?: "Couldn't check this project for changes.", title = "Couldn't check for changes") { openPushChanges(projectId) }
            }
        }
    }

    fun updatePushChangesCommitMessage(message: String) {
        _uiState.update { it.copy(pushChangesCommitMessage = message) }
    }

    fun toggleReviewChangesSheet(show: Boolean) {
        _uiState.update { it.copy(showReviewChangesSheet = show) }
    }

    fun confirmPushChanges(projectId: String) {
        val scanned = currentScannedProject
        if (scanned == null) {
            showError("Couldn't read the project folder. Please try again.", title = "Couldn't push changes") { openPushChanges(projectId) }
            return
        }
        val commitMessage = _uiState.value.pushChangesCommitMessage.ifBlank { "Update project" }

        uploadJob?.cancel()
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.UploadProgress,
                isUploading = true,
                uploadStageIndex = 2,
                uploadedFilesCount = 0,
                totalFilesCount = scanned.files.size,
                uploadProgressPercent = 0f
            )
        }

        uploadJob = viewModelScope.launch {
            try {
                val entity = syncRepository.getProject(projectId) ?: throw IllegalStateException("This project is no longer available.")
                _uiState.update { it.copy(activePushRepoFullName = entity.repoFullName) }

                val outcome = syncRepository.pushChanges(
                    projectId = projectId,
                    scanned = scanned,
                    owner = entity.ownerLogin,
                    repo = entity.repoName,
                    branch = entity.branch,
                    commitMessage = commitMessage
                ) { uploaded, total, uploadedBytes, totalBytes ->
                    _uiState.update {
                        it.copy(
                            uploadStageIndex = 3,
                            uploadedFilesCount = uploaded,
                            totalFilesCount = total.coerceAtLeast(1),
                            uploadProgressPercent = if (total > 0) uploaded.toFloat() / total else 1f
                        )
                    }
                }

                if (outcome == null) {
                    _uiState.update { it.copy(isUploading = false, currentScreen = AppScreen.NoChanges(projectId)) }
                    return@launch
                }

                _uiState.update { it.copy(uploadStageIndex = 4, uploadProgressPercent = 1f) }

                val updatedEntity = entity.copy(
                    lastPushedAtMillis = System.currentTimeMillis(),
                    lastCommitSha = outcome.commitSha,
                    lastCommitMessage = commitMessage,
                    lastFileCount = scanned.files.size,
                    lastSizeBytes = scanned.totalSizeBytes
                )
                syncRepository.saveProject(updatedEntity)

                val newActivity = SyncActivityItem(
                    id = "act_${System.currentTimeMillis()}",
                    projectName = updatedEntity.name,
                    actionText = "Pushed changes",
                    timeText = "Just now",
                    statusText = "Synced",
                    commitMessage = commitMessage,
                    commitHash = outcome.commitSha.take(7)
                )
                _uiState.update {
                    it.copy(
                        isUploading = false,
                        activities = listOf(newActivity) + it.activities,
                        currentScreen = AppScreen.PushSuccess,
                        wizardProjectName = updatedEntity.name
                    )
                }
            } catch (e: GitHubException.PermissionDenied) {
                showPermissionRequiredError(e, forCreateRepo = false)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(isUploading = false) }
                showError(e.message ?: "The push failed. Please try again.", title = "Couldn't push changes") { confirmPushChanges(projectId) }
            }
        }
    }

    // ---------------- Project Removal ----------------

    fun requestRemoveProject(project: Project) {
        _uiState.update { it.copy(showRemoveProjectDialog = true, projectPendingRemoval = project) }
    }

    fun dismissRemoveProjectDialog() {
        _uiState.update { it.copy(showRemoveProjectDialog = false, projectPendingRemoval = null) }
    }

    fun confirmRemoveProject() {
        val pending = _uiState.value.projectPendingRemoval ?: return
        viewModelScope.launch {
            val entity = syncRepository.getProject(pending.id)
            val uri = entity?.folderUri?.let { Uri.parse(it) }
            syncRepository.deleteProject(pending.id, uri)
            _uiState.update {
                it.copy(
                    showRemoveProjectDialog = false,
                    projectPendingRemoval = null,
                    currentScreen = AppScreen.Projects
                )
            }
        }
    }

    // ---------------- Search filters ----------------

    fun updateProjectSearch(query: String) {
        _uiState.update { it.copy(projectSearchQuery = query) }
    }

    fun updateRepoSearch(query: String) {
        _uiState.update { it.copy(repoSearchQuery = query) }
    }

    // ---------------- Explainer dialog ----------------

    fun toggleWhyGitHubAccessDialog(show: Boolean) {
        _uiState.update { it.copy(showWhyGitHubAccessDialog = show) }
    }

    // ---------------- Mappers ----------------

    private fun ProjectEntity.toProject(): Project = Project(
        id = id,
        name = name,
        repoFullName = repoFullName,
        localFolder = name,
        fileCount = lastFileCount,
        sizeMb = ProjectFileRepository.bytesToMb(lastSizeBytes),
        lastPushedText = formatRelativeTime(lastPushedAtMillis),
        branch = branch,
        status = SyncStatus.SYNCED,
        isPrivate = isPrivate,
        description = description,
        latestCommitMessage = lastCommitMessage
    )

    private fun RecentFolderEntity.toFolderCandidate(): FolderCandidate = FolderCandidate(
        name = displayName,
        relativePath = displayPath,
        fullPath = treeUri,
        fileCount = fileCount,
        sizeMb = ProjectFileRepository.bytesToMb(sizeBytes),
        lastModified = formatRelativeTime(lastUsedAtMillis)
    )

    private fun String.toProjectFileItem(changeType: ChangeType): ProjectFileItem = ProjectFileItem(
        name = substringAfterLast('/'),
        path = this,
        isDirectory = false,
        type = ProjectFileRepository.inferFileType(this),
        changeType = changeType
    )

    private fun sanitizeRepoName(name: String): String {
        val replaced = name.trim().replace(Regex("[^A-Za-z0-9._-]"), "-")
        return replaced.ifBlank { "project" }
    }

    private fun formatRelativeTime(millis: Long): String {
        if (millis <= 0L) return "Never"
        val diffMinutes = (System.currentTimeMillis() - millis) / 60000
        return when {
            diffMinutes < 1 -> "Just now"
            diffMinutes < 60 -> "$diffMinutes min ago"
            diffMinutes < 60 * 24 -> "${diffMinutes / 60} hr ago"
            else -> "${diffMinutes / (60 * 24)} d ago"
        }
    }
}
