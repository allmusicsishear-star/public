package com.example.data.repository

import android.content.Context
import com.example.data.local.TokenStore
import com.example.data.remote.CreateRepoRequestDto
import com.example.data.remote.GitHubApi
import com.example.data.remote.GitHubRepoDto
import com.example.data.remote.NetworkModule

data class RemoteRepo(
    val id: Long,
    val name: String,
    val ownerLogin: String,
    val fullName: String,
    val isPrivate: Boolean,
    val description: String,
    val defaultBranch: String,
    val htmlUrl: String,
    val canPush: Boolean
)

class GitHubRepoRepository(
    context: Context,
    tokenStore: TokenStore
) {
    private val api: GitHubApi = NetworkModule.createGitHubApi(context, tokenStore)

    /** Fetches every repo the authenticated user can access, across all pages. */
    suspend fun listAllRepos(): List<RemoteRepo> = runGitHubCall("list_repositories") {
        val all = mutableListOf<GitHubRepoDto>()
        var page = 1
        while (true) {
            val batch = api.listRepos(perPage = 100, page = page)
            all += batch
            if (batch.size < 100) break
            page++
            // Safety cap so a runaway account with thousands of repos
            // can't turn this into an unbounded loop.
            if (page > 20) break
        }
        all.map { it.toRemoteRepo() }
    }

    suspend fun createRepository(name: String, description: String, isPrivate: Boolean): RemoteRepo {
        return runGitHubCall("create_repository") {
            val dto = api.createRepo(
                CreateRepoRequestDto(
                    name = name,
                    description = description,
                    isPrivate = isPrivate,
                    autoInit = false
                )
            )
            dto.toRemoteRepo()
        }
    }

    private fun GitHubRepoDto.toRemoteRepo() = RemoteRepo(
        id = id,
        name = name,
        ownerLogin = owner.login,
        fullName = fullName,
        isPrivate = isPrivate,
        description = description.orEmpty(),
        defaultBranch = defaultBranch ?: "main",
        htmlUrl = htmlUrl,
        canPush = permissions?.push ?: true
    )
}
