package com.example.data

enum class SyncStatus {
    SYNCED,
    CHANGES_FOUND,
    PUSHING,
    ERROR,
    UNTRACKED
}

enum class FileType {
    DIRECTORY,
    KOTLIN,
    GRADLE,
    XML,
    JSON,
    MARKDOWN,
    GENERIC
}

enum class ChangeType {
    UNMODIFIED,
    MODIFIED,
    ADDED,
    DELETED
}

enum class DeviceAuthStatus {
    DISCONNECTED,
    REQUESTING_CODE,
    AWAITING_USER,
    EXCHANGING_TOKEN
}

/**
 * GitHub user authorization (having a valid token) and GitHub App
 * installation (the App actually being granted access on the account) are
 * separate GitHub concepts. This tracks the latter.
 */
enum class InstallationStatus {
    UNKNOWN,
    NOT_INSTALLED,
    INSTALLED
}

data class ProjectFileItem(
    val name: String,
    val path: String,
    val isDirectory: Boolean = false,
    val type: FileType = FileType.GENERIC,
    val changeType: ChangeType = ChangeType.UNMODIFIED,
    val sizeText: String = ""
)

data class Project(
    val id: String,
    val name: String,
    val repoFullName: String,
    val localFolder: String,
    val fileCount: Int,
    val sizeMb: Double,
    val lastPushedText: String,
    val branch: String = "main",
    val status: SyncStatus = SyncStatus.SYNCED,
    val isPrivate: Boolean = true,
    val description: String = "",
    val latestCommitMessage: String = "Initial project upload",
    val changedFilesCount: Int = 0,
    val addedFilesCount: Int = 0,
    val deletedFilesCount: Int = 0,
    val files: List<ProjectFileItem> = emptyList()
)

data class SyncActivityItem(
    val id: String,
    val projectName: String,
    val actionText: String,
    val timeText: String,
    val statusText: String = "Synced",
    val commitMessage: String = "",
    val commitHash: String = ""
)

data class GitHubRepo(
    val id: String,
    val name: String,
    val owner: String,
    val fullName: String,
    val isPrivate: Boolean,
    val description: String,
    val defaultBranch: String = "main",
    val updatedAtText: String = "Updated recently"
)

data class GitHubAccount(
    val username: String = "",
    val displayName: String? = null,
    val isConnected: Boolean = false,
    val avatarInitials: String = "",
    val repoCount: Int = 0
)

data class FolderCandidate(
    val name: String,
    val relativePath: String,
    val fullPath: String,
    val fileCount: Int,
    val sizeMb: Double,
    val lastModified: String = ""
)
