package com.example.data.util

/**
 * A pragmatic (not 100% git-spec-complete) .gitignore matcher. It supports
 * what the overwhelming majority of real-world Android project .gitignore
 * files actually use:
 *  - blank lines and `#` comments are skipped
 *  - `!pattern` negates a previous match
 *  - a leading `/` anchors the pattern to the project root
 *  - a trailing `/` restricts the pattern to directories
 *  - `*` matches any run of characters except `/`
 *  - `?` matches a single character except `/`
 *  - `**` matches across directory boundaries
 *
 * Nested .gitignore files (one per sub-directory) are not merged in; only
 * the project root's .gitignore is honored. This covers the vast majority
 * of Android projects, which keep a single root .gitignore.
 */
class GitIgnoreMatcher private constructor(private val rules: List<Rule>) {

    private data class Rule(
        val regex: Regex,
        val negation: Boolean,
        val dirOnly: Boolean,
        val anchored: Boolean
    )

    /**
     * @param relativePath project-root-relative path using `/` separators,
     *   with no leading slash (e.g. "app/build/outputs/foo.apk")
     */
    fun isIgnored(relativePath: String, isDirectory: Boolean): Boolean {
        var ignored = false
        for (rule in rules) {
            if (rule.dirOnly && !isDirectory) continue
            val matched = if (rule.anchored) {
                rule.regex.matches(relativePath)
            } else {
                // Unanchored: match the full path or any path suffix that
                // starts at a path segment boundary (mirrors git's
                // "pattern matches anywhere in the tree" behavior for
                // patterns with no slash).
                rule.regex.matches(relativePath) ||
                    relativePath.substringAfterLastPathSeparatorSequences().any { rule.regex.matches(it) }
            }
            if (matched) {
                ignored = !rule.negation
            }
        }
        return ignored
    }

    private fun String.substringAfterLastPathSeparatorSequences(): List<String> {
        val segments = this.split('/')
        val suffixes = mutableListOf<String>()
        for (i in segments.indices) {
            suffixes.add(segments.subList(i, segments.size).joinToString("/"))
        }
        return suffixes
    }

    companion object {
        /** Always-ignored regardless of .gitignore contents: VCS internals. */
        private val ALWAYS_IGNORE = listOf(".git")

        fun parse(gitignoreContent: String?): GitIgnoreMatcher {
            val rules = mutableListOf<Rule>()
            gitignoreContent?.lineSequence()?.forEach { rawLine ->
                var line = rawLine.trimEnd()
                if (line.isBlank() || line.trimStart().startsWith("#")) return@forEach

                var negation = false
                if (line.startsWith("!")) {
                    negation = true
                    line = line.substring(1)
                }

                // Handle escaped leading '#' or '!' (rare, but cheap to support)
                if (line.startsWith("\\#") || line.startsWith("\\!")) {
                    line = line.substring(1)
                }

                var dirOnly = false
                if (line.endsWith("/")) {
                    dirOnly = true
                    line = line.removeSuffix("/")
                }
                if (line.isBlank()) return@forEach

                var anchored = line.startsWith("/")
                if (anchored) line = line.removePrefix("/")
                if (line.contains("/")) anchored = true

                rules.add(Rule(globToRegex(line), negation, dirOnly, anchored))
            }
            ALWAYS_IGNORE.forEach { name ->
                rules.add(Rule(globToRegex(name), negation = false, dirOnly = false, anchored = false))
            }
            return GitIgnoreMatcher(rules)
        }

        private fun globToRegex(glob: String): Regex {
            val sb = StringBuilder()
            var i = 0
            while (i < glob.length) {
                val c = glob[i]
                when {
                    glob.startsWith("**/", i) -> {
                        sb.append("(?:.*/)?")
                        i += 3
                        continue
                    }
                    c == '*' -> sb.append("[^/]*")
                    c == '?' -> sb.append("[^/]")
                    c == '.' -> sb.append("\\.")
                    c in "\\^$+{}()|[]" -> sb.append("\\").append(c)
                    else -> sb.append(c)
                }
                i++
            }
            return Regex("^$sb$")
        }
    }
}
