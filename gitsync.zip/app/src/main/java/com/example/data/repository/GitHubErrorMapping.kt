package com.example.data.repository

import com.example.data.remote.GitHubApiErrorDto
import com.example.data.remote.GitHubDiagnostics
import com.example.data.remote.GitHubException
import com.example.data.remote.NetworkModule
import retrofit2.HttpException
import java.io.IOException

/**
 * Runs [block] and rethrows any failure as a [GitHubException], so every
 * screen can rely on the same handful of error types regardless of which
 * GitHub endpoint failed. [action] is a short, non-sensitive label (e.g.
 * "create_repository", "push_initial") used only for diagnostics — never a
 * URL, and never anything containing the token.
 */
suspend fun <T> runGitHubCall(action: String, block: suspend () -> T): T {
    return try {
        block()
    } catch (e: IOException) {
        GitHubDiagnostics.logApiError(action, httpStatus = null, githubMessage = "No internet connection")
        throw GitHubException.NoInternet()
    } catch (e: HttpException) {
        throw mapHttpException(action, e)
    }
}

private fun mapHttpException(action: String, e: HttpException): GitHubException {
    val response = e.response()
    val body = response?.errorBody()?.string()
    val message = parseErrorMessage(body)
    val requestId = response?.headers()?.get("X-GitHub-Request-Id")
    val acceptedPermissions = response?.headers()?.get("X-Accepted-GitHub-Permissions")

    GitHubDiagnostics.logApiError(action, e.code(), message, acceptedPermissions, requestId)

    return when (e.code()) {
        401 -> GitHubException.Unauthorized()
        403 -> {
            val remaining = response?.headers()?.get("X-RateLimit-Remaining")
            val reset = response?.headers()?.get("X-RateLimit-Reset")?.toLongOrNull()
            if (remaining == "0" && reset != null) {
                val secondsLeft = reset - (System.currentTimeMillis() / 1000)
                GitHubException.RateLimited(secondsLeft)
            } else {
                // Preserve GitHub's real message verbatim (e.g. "Resource
                // not accessible by integration") plus whatever it tells us
                // about the permission it actually wanted, rather than a
                // generic string — this is what lets a 403 be diagnosed
                // (missing installation vs. missing permission vs. stale
                // token) instead of guessed at.
                GitHubException.PermissionDenied(message, acceptedPermissions, requestId)
            }
        }
        404 -> GitHubException.RepositoryNotFound()
        409 -> GitHubException.BranchConflict()
        422 -> {
            // GitHub's real non-fast-forward rejection for "Update a
            // reference" is a 422 with message "Update is not a fast
            // forward" (confirmed in GitHub's own REST API reference) —
            // NOT a 409. That is exactly the "remote branch changed since
            // your last sync" case, so it must map to the same conflict
            // message/UI as a 409 would, not the generic validation error.
            if (message?.contains("fast forward", ignoreCase = true) == true) {
                GitHubException.BranchConflict()
            } else {
                GitHubException.ValidationFailed(message)
            }
        }
        in 500..599 -> GitHubException.ServerError()
        else -> GitHubException.Unknown(message)
    }
}

/**
 * Parses GitHub's error body, including the `errors[]` array GitHub often
 * includes on 422s with the actually-useful detail (the top-level
 * `message` alone is frequently a generic string like "Repository creation
 * failed."). When present, sub-error messages/fields are appended so the
 * real cause isn't hidden behind that generic text.
 */
private fun parseErrorMessage(body: String?): String? {
    if (body.isNullOrBlank()) return null
    return try {
        val adapter = NetworkModule.moshi.adapter(GitHubApiErrorDto::class.java)
        val parsed = adapter.fromJson(body) ?: return null
        val base = parsed.message
        val subDetails = parsed.errors
            ?.mapNotNull { sub ->
                val detail = sub.message ?: sub.code
                if (detail.isNullOrBlank()) null else {
                    val field = sub.field?.let { "$it: " } ?: ""
                    "$field$detail"
                }
            }
            ?.filter { it.isNotBlank() }
            .orEmpty()
        when {
            base.isNullOrBlank() && subDetails.isEmpty() -> null
            subDetails.isEmpty() -> base
            base.isNullOrBlank() -> subDetails.joinToString("; ")
            else -> "$base (${subDetails.joinToString("; ")})"
        }
    } catch (e: Exception) {
        null
    }
}
