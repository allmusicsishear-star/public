package com.example.data.util

import java.security.MessageDigest

/**
 * Computes the same SHA-1 git uses to identify a blob: sha1("blob " + size + "\0" + content).
 * Comparing this locally against the SHA recorded from the last successful
 * push is how we detect modified files without contacting GitHub.
 */
object GitBlobSha {
    fun of(content: ByteArray): String {
        val header = "blob ${content.size}\u0000".toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-1")
        digest.update(header)
        digest.update(content)
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
