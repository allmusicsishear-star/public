package com.example.data.repository

sealed class LocalFileException(message: String) : Exception(message) {
    class FolderPermissionRevoked : LocalFileException(
        "GitSync no longer has access to this folder. Please choose it again."
    )
    class FolderUnreadable : LocalFileException(
        "This folder couldn't be read. It may have been moved or deleted."
    )
    class FileUnreadable(fileName: String) : LocalFileException(
        "Couldn't read \"$fileName\". It may be locked or no longer exist."
    )
    class FileTooLarge(fileName: String, sizeMb: Double) : LocalFileException(
        "\"$fileName\" is %.1f MB, which is larger than GitHub's 100 MB per-file limit and can't be uploaded via the API.".format(sizeMb)
    )
}
