package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.example.data.ChangeType
import com.example.data.FileType
import com.example.data.ProjectFileItem
import com.example.data.util.GitIgnoreMatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

/** One real, non-ignored file found while scanning the project folder. */
data class ScannedFile(
    val relativePath: String,
    val sizeBytes: Long,
    val documentUri: Uri
)

data class ScannedProject(
    val rootDisplayName: String,
    val files: List<ScannedFile>,
    val totalSizeBytes: Long,
    /** Top-level entries only, for the existing "Files" preview card. */
    val previewItems: List<ProjectFileItem>
)

const val GITHUB_MAX_BLOB_BYTES = 100L * 1024 * 1024

class ProjectFileRepository(private val context: Context) {

    /** Persists read/write access to [treeUri] across app restarts. */
    fun persistPermission(treeUri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        context.contentResolver.takePersistableUriPermission(treeUri, flags)
    }

    fun releasePermission(treeUri: Uri) {
        try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.releasePersistableUriPermission(treeUri, flags)
        } catch (e: SecurityException) {
            // Already released or never held — safe to ignore.
        }
    }

    /** True if we still hold a persisted permission grant for [treeUri]. */
    fun hasPersistedPermission(treeUri: Uri): Boolean {
        return context.contentResolver.persistedUriPermissions.any {
            it.uri == treeUri && it.isReadPermission
        }
    }

    suspend fun scanProject(treeUri: Uri): ScannedProject = withContext(Dispatchers.IO) {
        if (!hasPersistedPermission(treeUri)) {
            throw LocalFileException.FolderPermissionRevoked()
        }
        val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw LocalFileException.FolderUnreadable()
        if (!rootDoc.isDirectory) throw LocalFileException.FolderUnreadable()

        val gitIgnore = GitIgnoreMatcher.parse(readGitIgnore(rootDoc))

        val files = mutableListOf<ScannedFile>()
        val previewItems = mutableListOf<ProjectFileItem>()

        fun walk(dir: DocumentFile, relativePrefix: String, isRoot: Boolean) {
            val children = try {
                dir.listFiles()
            } catch (e: Exception) {
                throw LocalFileException.FolderUnreadable()
            }
            for (child in children) {
                val name = child.name ?: continue
                val relPath = if (relativePrefix.isEmpty()) name else "$relativePrefix/$name"
                val isDir = child.isDirectory
                if (gitIgnore.isIgnored(relPath, isDir)) continue

                if (isDir) {
                    if (isRoot) {
                        previewItems.add(
                            ProjectFileItem(
                                name = "$name/",
                                path = relPath,
                                isDirectory = true,
                                type = FileType.DIRECTORY
                            )
                        )
                    }
                    walk(child, relPath, false)
                } else {
                    val size = child.length()
                    files.add(ScannedFile(relPath, size, child.uri))
                    if (isRoot) {
                        previewItems.add(
                            ProjectFileItem(
                                name = name,
                                path = relPath,
                                isDirectory = false,
                                type = inferFileType(name),
                                sizeText = formatSize(size)
                            )
                        )
                    }
                }
            }
        }
        walk(rootDoc, "", true)

        ScannedProject(
            rootDisplayName = rootDoc.name ?: "Project",
            files = files,
            totalSizeBytes = files.sumOf { it.sizeBytes },
            previewItems = previewItems.sortedWith(compareBy({ !it.isDirectory }, { it.name }))
        )
    }

    /** Reads the full content of one scanned file. Used lazily per-file during upload. */
    suspend fun readFileBytes(uri: Uri, displayName: String): ByteArray = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw LocalFileException.FileUnreadable(displayName)
        } catch (e: IOException) {
            throw LocalFileException.FileUnreadable(displayName)
        }
    }

    private fun readGitIgnore(rootDoc: DocumentFile): String? {
        val gitIgnoreDoc = rootDoc.findFile(".gitignore") ?: return null
        return try {
            context.contentResolver.openInputStream(gitIgnoreDoc.uri)?.use {
                it.readBytes().toString(Charsets.UTF_8)
            }
        } catch (e: IOException) {
            null
        }
    }

    companion object {
        fun inferFileType(fileName: String): FileType = when {
            fileName.endsWith(".kt") || fileName.endsWith(".kts") && !fileName.endsWith(".gradle.kts") -> FileType.KOTLIN
            fileName.endsWith(".gradle") || fileName.endsWith(".gradle.kts") -> FileType.GRADLE
            fileName.endsWith(".xml") -> FileType.XML
            fileName.endsWith(".json") -> FileType.JSON
            fileName.endsWith(".md") || fileName.endsWith(".markdown") -> FileType.MARKDOWN
            else -> FileType.GENERIC
        }

        fun formatSize(bytes: Long): String = when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
            else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        }

        fun bytesToMb(bytes: Long): Double {
            val mb = bytes / (1024.0 * 1024.0)
            return kotlin.math.round(mb * 10.0) / 10.0
        }
    }
}
