package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

// ---------- OAuth Device Flow (github.com) ----------

@JsonClass(generateAdapter = true)
data class DeviceCodeResponseDto(
    @Json(name = "device_code") val deviceCode: String,
    @Json(name = "user_code") val userCode: String,
    @Json(name = "verification_uri") val verificationUri: String,
    @Json(name = "expires_in") val expiresIn: Int,
    val interval: Int
)

/**
 * GitHub's access-token polling endpoint always answers with HTTP 200 and
 * distinguishes success/pending/error purely by which fields are present.
 *
 * For a GitHub App (as opposed to a classic OAuth App), [expiresIn] /
 * [refreshToken] / [refreshTokenExpiresIn] are only present if the App
 * owner opted into "Expire user authorization tokens". When absent, the
 * access token does not expire.
 */
@JsonClass(generateAdapter = true)
data class AccessTokenResponseDto(
    @Json(name = "access_token") val accessToken: String? = null,
    @Json(name = "token_type") val tokenType: String? = null,
    val scope: String? = null,
    val error: String? = null,
    @Json(name = "error_description") val errorDescription: String? = null,
    val interval: Int? = null,
    @Json(name = "expires_in") val expiresIn: Long? = null,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    @Json(name = "refresh_token_expires_in") val refreshTokenExpiresIn: Long? = null
)

// ---------- REST API (api.github.com) ----------

@JsonClass(generateAdapter = true)
data class GitHubUserDto(
    val login: String,
    val id: Long,
    val name: String?,
    @Json(name = "avatar_url") val avatarUrl: String?,
    @Json(name = "public_repos") val publicRepos: Int? = null,
    @Json(name = "total_private_repos") val totalPrivateRepos: Int? = null
)

@JsonClass(generateAdapter = true)
data class GitHubOwnerDto(
    val login: String
)

@JsonClass(generateAdapter = true)
data class GitHubRepoDto(
    val id: Long,
    val name: String,
    @Json(name = "full_name") val fullName: String,
    val owner: GitHubOwnerDto,
    @Json(name = "private") val isPrivate: Boolean,
    val description: String?,
    @Json(name = "default_branch") val defaultBranch: String?,
    @Json(name = "html_url") val htmlUrl: String,
    @Json(name = "updated_at") val updatedAt: String?,
    val permissions: GitHubRepoPermissionsDto? = null
)

@JsonClass(generateAdapter = true)
data class GitHubRepoPermissionsDto(
    val push: Boolean? = null,
    val admin: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class CreateRepoRequestDto(
    val name: String,
    val description: String,
    @Json(name = "private") val isPrivate: Boolean,
    @Json(name = "auto_init") val autoInit: Boolean = false
)

@JsonClass(generateAdapter = true)
data class GitRefObjectDto(
    val sha: String,
    val type: String
)

@JsonClass(generateAdapter = true)
data class GitRefDto(
    val ref: String,
    @Json(name = "object") val refObject: GitRefObjectDto
)

@JsonClass(generateAdapter = true)
data class CreateRefRequestDto(
    val ref: String,
    val sha: String
)

@JsonClass(generateAdapter = true)
data class UpdateRefRequestDto(
    val sha: String,
    val force: Boolean = false
)

@JsonClass(generateAdapter = true)
data class GitCommitTreeRefDto(
    val sha: String
)

@JsonClass(generateAdapter = true)
data class GitCommitDto(
    val sha: String,
    val tree: GitCommitTreeRefDto,
    val parents: List<GitCommitTreeRefDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class CreateBlobRequestDto(
    val content: String,
    val encoding: String = "base64"
)

@JsonClass(generateAdapter = true)
data class CreateBlobResponseDto(
    val sha: String
)

@JsonClass(generateAdapter = true)
data class TreeEntryDto(
    val path: String,
    val mode: String,
    val type: String,
    // null sha in a tree entry tells GitHub to remove that path.
    val sha: String?
)

@JsonClass(generateAdapter = true)
data class CreateTreeRequestDto(
    @Json(name = "base_tree") val baseTree: String?,
    val tree: List<TreeEntryDto>
)

@JsonClass(generateAdapter = true)
data class CreateTreeResponseDto(
    val sha: String
)

@JsonClass(generateAdapter = true)
data class CreateCommitRequestDto(
    val message: String,
    val tree: String,
    val parents: List<String>
)

@JsonClass(generateAdapter = true)
data class CreateCommitResponseDto(
    val sha: String
)

@JsonClass(generateAdapter = true)
data class GitHubApiErrorDto(
    val message: String?,
    @Json(name = "documentation_url") val documentationUrl: String? = null,
    val errors: List<GitHubApiSubErrorDto>? = null
)

@JsonClass(generateAdapter = true)
data class GitHubApiSubErrorDto(
    val resource: String? = null,
    val field: String? = null,
    val code: String? = null,
    val message: String? = null
)

// ---------- GitHub App installations accessible to the user token ----------

@JsonClass(generateAdapter = true)
data class InstallationsResponseDto(
    @Json(name = "total_count") val totalCount: Int,
    val installations: List<InstallationDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class InstallationDto(
    val id: Long,
    @Json(name = "app_id") val appId: Long,
    @Json(name = "app_slug") val appSlug: String? = null,
    val permissions: InstallationPermissionsDto? = null,
    val account: InstallationAccountDto? = null
)

@JsonClass(generateAdapter = true)
data class InstallationPermissionsDto(
    val contents: String? = null,
    val administration: String? = null,
    val metadata: String? = null
)

@JsonClass(generateAdapter = true)
data class InstallationAccountDto(
    val login: String? = null
)

// ---------- Contents API (used only to bootstrap a truly empty repository) ----------

@JsonClass(generateAdapter = true)
data class CreateOrUpdateFileContentsRequestDto(
    val message: String,
    val content: String,
    val branch: String? = null,
    val sha: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateOrUpdateFileContentsResponseDto(
    val commit: CommitShaDto
)

@JsonClass(generateAdapter = true)
data class CommitShaDto(
    val sha: String
)
