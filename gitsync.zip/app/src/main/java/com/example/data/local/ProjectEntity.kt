package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A project the user has connected once. Persists everything needed to
 * reopen the project after an app restart and push further changes:
 * the SAF folder URI (permission for it is persisted separately via
 * [android.content.ContentResolver.takePersistableUriPermission]), and the
 * GitHub repository it is linked to.
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val folderUri: String,
    val ownerLogin: String,
    val repoName: String,
    val repoFullName: String,
    val branch: String,
    val isPrivate: Boolean,
    val description: String,
    val lastPushedAtMillis: Long,
    val lastCommitSha: String?,
    val lastCommitMessage: String,
    val lastFileCount: Int,
    val lastSizeBytes: Long
)
