package com.example.data.remote

import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Talks to `github.com/login/...` — the OAuth Device Flow endpoints. These
 * live on a different host than the REST API and must NOT receive the
 * Bearer auth header (there is no token yet at this point).
 */
interface GitHubDeviceAuthApi {

    // Note: this is a GitHub App (not a classic OAuth App) device flow, so
    // no `scope` parameter is sent — access is governed by the permissions
    // configured on the App itself (Contents, Metadata, Administration).
    @FormUrlEncoded
    @Headers("Accept: application/json")
    @POST("login/device/code")
    suspend fun requestDeviceCode(
        @Field("client_id") clientId: String
    ): DeviceCodeResponseDto

    @FormUrlEncoded
    @Headers("Accept: application/json")
    @POST("login/oauth/access_token")
    suspend fun pollAccessToken(
        @Field("client_id") clientId: String,
        @Field("device_code") deviceCode: String,
        @Field("grant_type") grantType: String = "urn:ietf:params:oauth:grant-type:device_code"
    ): AccessTokenResponseDto

    @FormUrlEncoded
    @Headers("Accept: application/json")
    @POST("login/oauth/access_token")
    suspend fun refreshAccessToken(
        @Field("client_id") clientId: String,
        @Field("refresh_token") refreshToken: String,
        @Field("grant_type") grantType: String = "refresh_token"
    ): AccessTokenResponseDto
}

/**
 * Talks to `api.github.com`. Every call here is authenticated with the
 * stored access token via [AuthInterceptor].
 */
interface GitHubApi {

    @GET("user")
    suspend fun getAuthenticatedUser(): GitHubUserDto

    @GET("user/repos")
    suspend fun listRepos(
        @Query("per_page") perPage: Int = 100,
        @Query("page") page: Int = 1,
        @Query("sort") sort: String = "updated",
        @Query("affiliation") affiliation: String = "owner,collaborator,organization_member"
    ): List<GitHubRepoDto>

    @POST("user/repos")
    suspend fun createRepo(@Body body: CreateRepoRequestDto): GitHubRepoDto

    @GET("repos/{owner}/{repo}/git/ref/heads/{branch}")
    suspend fun getBranchRef(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("branch") branch: String
    ): GitRefDto

    @POST("repos/{owner}/{repo}/git/refs")
    suspend fun createRef(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body body: CreateRefRequestDto
    ): GitRefDto

    @PATCH("repos/{owner}/{repo}/git/refs/heads/{branch}")
    suspend fun updateBranchRef(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("branch") branch: String,
        @Body body: UpdateRefRequestDto
    ): GitRefDto

    @GET("repos/{owner}/{repo}/git/commits/{sha}")
    suspend fun getCommit(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("sha") sha: String
    ): GitCommitDto

    @POST("repos/{owner}/{repo}/git/blobs")
    suspend fun createBlob(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body body: CreateBlobRequestDto
    ): CreateBlobResponseDto

    @POST("repos/{owner}/{repo}/git/trees")
    suspend fun createTree(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body body: CreateTreeRequestDto
    ): CreateTreeResponseDto

    @POST("repos/{owner}/{repo}/git/commits")
    suspend fun createCommit(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Body body: CreateCommitRequestDto
    ): CreateCommitResponseDto

    @DELETE("repos/{owner}/{repo}")
    suspend fun deleteRepo(
        @Path("owner") owner: String,
        @Path("repo") repo: String
    )

    /**
     * GitHub-documented endpoint for "List app installations accessible to
     * the user access token" — the supported way for a GitHub App user
     * token to discover which installation(s) of which App(s) the current
     * user has, and what permissions each installation actually has. This
     * is how GitSync tells GitHub-user-authorization apart from GitHub-App
     * installation.
     */
    @GET("user/installations")
    suspend fun listUserInstallations(): InstallationsResponseDto

    /**
     * Contents API — used ONLY to bootstrap a brand-new, completely empty
     * repository (zero commits). The Git Database API (blobs/trees/commits)
     * refuses to operate on such a repository with 409 "Git Repository is
     * empty."; GitHub's own docs say the supported fix is to create the
     * first file through this endpoint, which creates the branch and an
     * initial commit as a side effect.
     */
    @PUT("repos/{owner}/{repo}/contents/{path}")
    suspend fun createOrUpdateFileContents(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path(value = "path", encoded = true) path: String,
        @Body body: CreateOrUpdateFileContentsRequestDto
    ): CreateOrUpdateFileContentsResponseDto
}
