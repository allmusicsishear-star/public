package com.example.data.remote

import android.util.Log

/**
 * TEMPORARY diagnostic logging for investigating GitHub API failures
 * (Create Repository, Push, installation checks, etc). Logs ONLY:
 *  - the action/endpoint being attempted (a short label we choose, e.g.
 *    "create_repository" — never a URL containing a token)
 *  - HTTP status
 *  - GitHub's JSON error message
 *  - X-Accepted-GitHub-Permissions
 *  - X-GitHub-Request-Id
 *  - the current GitHub username (a login name, not a secret)
 *
 * It NEVER logs the access token, refresh token, device code, user code,
 * Client ID/Secret, or any request/response header other than the two
 * named above. Safe to delete once these flows are confirmed working
 * end-to-end for arbitrary GitHub accounts — nothing else in the app
 * depends on this object.
 */
object GitHubDiagnostics {
    private const val TAG = "GitSyncDiag"

    /** Set right after a successful GET /user. Just a login name — not sensitive. */
    @Volatile
    var currentUsername: String? = null
        internal set

    fun logApiError(
        action: String,
        httpStatus: Int?,
        githubMessage: String?,
        acceptedPermissions: String? = null,
        requestId: String? = null
    ) {
        Log.w(
            TAG,
            "[$action] GitHub ${httpStatus ?: "?"} | user=${currentUsername ?: "unknown"} | " +
                "message=\"${githubMessage ?: "(none)"}\" | " +
                "X-Accepted-GitHub-Permissions=\"${acceptedPermissions ?: "(none)"}\" | " +
                "X-GitHub-Request-Id=\"${requestId ?: "(none)"}\""
        )
    }
}
