package com.example.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.BuildConfig
import com.example.data.local.TokenStore
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {

    private const val GITHUB_API_HOST = "api.github.com"
    private const val GITHUB_API_BASE_URL = "https://api.github.com/"
    private const val GITHUB_WEB_BASE_URL = "https://github.com/"

    val moshi: Moshi by lazy {
        Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    }

    fun isOnline(context: Context): Boolean {
        val cm = context.applicationContext
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Never logs headers (which would include the Authorization/Bearer token). */
    private fun loggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BASIC
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }
    }

    private fun authInterceptor(tokenStore: TokenStore) = okhttp3.Interceptor { chain ->
        val request = chain.request()
        val newRequest = if (request.url.host == GITHUB_API_HOST) {
            val token = tokenStore.getAccessToken()
            if (token.isNullOrBlank()) {
                request
            } else {
                request.newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .addHeader("Accept", "application/vnd.github+json")
                    .addHeader("X-GitHub-Api-Version", "2022-11-28")
                    .build()
            }
        } else {
            request
        }
        chain.proceed(newRequest)
    }

    private fun okHttpClient(tokenStore: TokenStore): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(authInterceptor(tokenStore))
            .addInterceptor(loggingInterceptor())
            .build()
    }

    fun createGitHubApi(context: Context, tokenStore: TokenStore): GitHubApi {
        val retrofit = Retrofit.Builder()
            .baseUrl(GITHUB_API_BASE_URL)
            .client(okHttpClient(tokenStore))
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        return retrofit.create(GitHubApi::class.java)
    }

    fun createDeviceAuthApi(tokenStore: TokenStore): GitHubDeviceAuthApi {
        // Uses its own OkHttpClient (no auth header needed/available yet)
        // but still wants a longer read timeout to be safe with slow networks.
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor())
            .build()
        val retrofit = Retrofit.Builder()
            .baseUrl(GITHUB_WEB_BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        return retrofit.create(GitHubDeviceAuthApi::class.java)
    }
}
