package com.example.data.local

import androidx.room.Entity

/**
 * Records the git blob SHA-1 of a file as of the last successful push for a
 * given project. Comparing a fresh scan's computed blob SHAs against these
 * records is how Push Changes detects added / modified / deleted files
 * without re-uploading or re-downloading anything.
 */
@Entity(tableName = "file_records", primaryKeys = ["projectId", "path"])
data class FileRecordEntity(
    val projectId: String,
    val path: String,
    val blobSha: String,
    val sizeBytes: Long
)
