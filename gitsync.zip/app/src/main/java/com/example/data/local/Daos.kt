package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY lastPushedAtMillis DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects ORDER BY lastPushedAtMillis DESC")
    suspend fun getAll(): List<ProjectEntity>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Upsert
    suspend fun upsert(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM projects")
    suspend fun clearAll()
}

@Dao
interface FileRecordDao {
    @Query("SELECT * FROM file_records WHERE projectId = :projectId")
    suspend fun getForProject(projectId: String): List<FileRecordEntity>

    @Upsert
    suspend fun upsertAll(records: List<FileRecordEntity>)

    @Query("DELETE FROM file_records WHERE projectId = :projectId AND path IN (:paths)")
    suspend fun deleteByPaths(projectId: String, paths: List<String>)

    @Query("DELETE FROM file_records WHERE projectId = :projectId")
    suspend fun deleteForProject(projectId: String)

    @Query("DELETE FROM file_records")
    suspend fun clearAll()

    /** Replace the entire snapshot for a project atomically. */
    @Transaction
    suspend fun replaceSnapshot(projectId: String, records: List<FileRecordEntity>) {
        deleteForProject(projectId)
        upsertAll(records)
    }
}

@Dao
interface RecentFolderDao {
    @Query("SELECT * FROM recent_folders ORDER BY lastUsedAtMillis DESC LIMIT 10")
    fun observeRecent(): Flow<List<RecentFolderEntity>>

    @Query("SELECT * FROM recent_folders ORDER BY lastUsedAtMillis DESC LIMIT 10")
    suspend fun getRecent(): List<RecentFolderEntity>

    @Upsert
    suspend fun upsert(folder: RecentFolderEntity)

    @Query("DELETE FROM recent_folders WHERE treeUri = :treeUri")
    suspend fun deleteByUri(treeUri: String)
}
