package com.example.data.repository

import android.content.Context
import com.example.data.InstallationStatus
import com.example.data.local.TokenStore
import com.example.data.remote.AccessTokenResponseDto
import com.example.data.remote.DeviceCodeResponseDto
import com.example.data.remote.DeviceFlowException
import com.example.data.remote.GitHubApi
import com.example.data.remote.GitHubDeviceAuthApi
import com.example.data.remote.GitHubDiagnostics
import com.example.data.remote.GitHubUserDto
import com.example.data.remote.NetworkModule
import kotlinx.coroutines.delay
import retrofit2.HttpException
import java.io.IOException

data class GitHubAccountInfo(
    val login: String,
    val displayName: String?,
    val avatarUrl: String?
)

data class InstallationCheckResult(
    val status: InstallationStatus,
    val hasContentsWrite: Boolean,
    val hasAdministrationWrite: Boolean
)

/** The public slug of GitSync Mobile's GitHub App, from https://github.com/apps/gitsync-mobile.
 *  This is a public identifier of OUR app (like the Client ID) — not a user credential. */
private const val GITHUB_APP_SLUG = "gitsync-mobile"
const val GITHUB_APP_INSTALL_URL = "https://github.com/apps/$GITHUB_APP_SLUG"

/**
 * Implements GitHub's OAuth Device Flow for a GitHub App:
 *  1. [requestDeviceCode] gets a user_code + verification_uri to show.
 *  2. [pollForAccessToken] polls until the user finishes authorizing on
 *     github.com/login/device, handling authorization_pending / slow_down /
 *     expired_token / access_denied per GitHub's spec.
 *  3. On success the token is stored via [TokenStore] (Keystore-backed,
 *     never logged) and [fetchAuthenticatedUser] loads the real account.
 *
 * No Personal Access Token, Client Secret, callback server, or third-party
 * backend is used anywhere in this flow.
 */
class GitHubAuthRepository(
    private val context: Context,
    private val tokenStore: TokenStore,
    private val clientId: String
) {
    private val deviceAuthApi: GitHubDeviceAuthApi = NetworkModule.createDeviceAuthApi(tokenStore)
    private val gitHubApi: GitHubApi = NetworkModule.createGitHubApi(context, tokenStore)

    /**
     * True only if a stored token exists AND it was issued for THIS GitHub
     * App (matching [clientId]). A GitHub App user-access-token is tied to
     * that specific App's identity, permissions, and installation — it is
     * not a bearer credential that happens to work for "GitHub" in general.
     *
     * If the stored token was minted under a different Client ID (e.g. an
     * old GitHub App from an earlier build, or after rotating to a new
     * App), it is discarded immediately here rather than reused: reusing it
     * would silently attach a token with the OLD app's (unknown, possibly
     * insufficient) permissions to requests made under the NEW app's
     * identity, which is exactly the kind of mismatch that produces a 403
     * "Resource not accessible by integration" on calls like Create
     * Repository even though the *new* App's configured permissions are
     * correct. This is real session migration: switching [clientId] always
     * forces a fresh Device Flow authorization.
     */
    fun isConnected(): Boolean {
        if (!tokenStore.hasAccessToken()) return false
        val storedClientId = tokenStore.getStoredClientId()
        if (storedClientId != clientId) {
            tokenStore.clear()
            return false
        }
        return true
    }

    suspend fun requestDeviceCode(): DeviceCodeResponseDto {
        if (!NetworkModule.isOnline(context)) throw DeviceFlowException.NoInternet()
        return try {
            deviceAuthApi.requestDeviceCode(clientId)
        } catch (e: IOException) {
            throw DeviceFlowException.NoInternet()
        } catch (e: HttpException) {
            throw DeviceFlowException.Other("GitHub rejected the sign-in request (${e.code()}).")
        }
    }

    /**
     * Suspends until the user finishes authorizing, or throws a
     * [DeviceFlowException]. Cancelling the calling coroutine (e.g. the
     * user backs out of Connect GitHub) stops the polling loop cleanly.
     */
    suspend fun pollForAccessToken(deviceCode: String, initialIntervalSeconds: Int): String {
        var intervalSeconds = initialIntervalSeconds.coerceAtLeast(5)
        while (true) {
            delay(intervalSeconds * 1000L)

            val response: AccessTokenResponseDto = try {
                deviceAuthApi.pollAccessToken(clientId, deviceCode)
            } catch (e: IOException) {
                throw DeviceFlowException.NoInternet()
            } catch (e: HttpException) {
                throw DeviceFlowException.Other("GitHub rejected the request (${e.code()}).")
            }

            when {
                !response.accessToken.isNullOrBlank() -> {
                    tokenStore.saveAccessToken(response.accessToken)
                    tokenStore.saveClientId(clientId)
                    if (!response.refreshToken.isNullOrBlank()) {
                        tokenStore.saveRefreshToken(response.refreshToken)
                    }
                    return response.accessToken
                }
                response.error == "authorization_pending" -> continue
                response.error == "slow_down" -> {
                    intervalSeconds = (response.interval ?: (intervalSeconds + 5))
                    continue
                }
                response.error == "expired_token" -> throw DeviceFlowException.ExpiredToken()
                response.error == "access_denied" -> throw DeviceFlowException.AccessDenied()
                else -> throw DeviceFlowException.Other(response.errorDescription ?: response.error)
            }
        }
    }

    suspend fun fetchAuthenticatedUser(): GitHubAccountInfo {
        val dto: GitHubUserDto = gitHubApi.getAuthenticatedUser()
        GitHubDiagnostics.currentUsername = dto.login
        return GitHubAccountInfo(
            login = dto.login,
            displayName = dto.name,
            avatarUrl = dto.avatarUrl
        )
    }

    /**
     * True if a DIFFERENT GitHub account was connected here previously.
     * Callers should wipe any per-account local data (Projects, sync
     * snapshots) before proceeding, so Account A's data is never shown to
     * or reused by Account B on the same device/app install.
     */
    fun didAccountChange(newLogin: String): Boolean {
        val previous = tokenStore.getStoredUsername()
        return previous != null && previous != newLogin
    }

    fun rememberUsername(login: String) {
        tokenStore.saveUsername(login)
    }

    /**
     * GitHub user authorization (this token existing) and GitHub App
     * installation (the App actually being granted access to repos on this
     * account) are separate states. This uses GitHub's documented "List app
     * installations accessible to the user access token" endpoint
     * (`GET /user/installations`) — the supported way for a user token to
     * discover this — rather than trusting a locally stored boolean.
     *
     * Never assumes personal ownership of the App: it matches by the
     * App's public slug (from its public install URL), so this works
     * identically for any GitHub user who has authorized GitSync.
     */
    suspend fun checkInstallation(): InstallationCheckResult {
        return try {
            val response = gitHubApi.listUserInstallations()
            val match = response.installations.find { it.appSlug == GITHUB_APP_SLUG }
            if (match == null) {
                InstallationCheckResult(InstallationStatus.NOT_INSTALLED, hasContentsWrite = false, hasAdministrationWrite = false)
            } else {
                val hasContents = match.permissions?.contents == "write"
                val hasAdmin = match.permissions?.administration == "write"
                val status = if (hasContents && hasAdmin) InstallationStatus.INSTALLED else InstallationStatus.NOT_INSTALLED
                InstallationCheckResult(status, hasContents, hasAdmin)
            }
        } catch (e: Exception) {
            // Network hiccup, rate limit, etc. — we genuinely don't know,
            // so we must not claim installed OR not-installed.
            InstallationCheckResult(InstallationStatus.UNKNOWN, hasContentsWrite = false, hasAdministrationWrite = false)
        }
    }

    /** Wipes the stored token(s). Called from Disconnect GitHub. */
    fun disconnect() {
        tokenStore.clear()
    }
}
