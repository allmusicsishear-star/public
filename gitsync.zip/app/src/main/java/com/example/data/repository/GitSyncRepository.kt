package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.data.local.AppDatabase
import com.example.data.local.FileRecordEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.RecentFolderEntity
import com.example.data.local.TokenStore
import com.example.data.remote.CreateBlobRequestDto
import com.example.data.remote.CreateCommitRequestDto
import com.example.data.remote.CreateOrUpdateFileContentsRequestDto
import com.example.data.remote.CreateRefRequestDto
import com.example.data.remote.CreateTreeRequestDto
import com.example.data.remote.GitHubApi
import com.example.data.remote.GitHubDiagnostics
import com.example.data.remote.GitHubException
import com.example.data.remote.GitRefDto
import com.example.data.remote.NetworkModule
import com.example.data.remote.TreeEntryDto
import com.example.data.remote.UpdateRefRequestDto
import com.example.data.util.GitBlobSha
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import retrofit2.HttpException

data class DiffSummary(
    val addedPaths: List<String>,
    val modifiedPaths: List<String>,
    val deletedPaths: List<String>
) {
    val hasChanges: Boolean get() = addedPaths.isNotEmpty() || modifiedPaths.isNotEmpty() || deletedPaths.isNotEmpty()
}

data class PushOutcome(
    val commitSha: String,
    val skippedFiles: List<String>
)

/**
 * Result of checking whether `refs/heads/{branch}` exists. GitHub's Git
 * Database API distinguishes two very different situations that both look
 * like "no ref" at first glance:
 *  - [BranchMissing] (HTTP 404): the repo has commits/branches, just not
 *    this one. Blobs/trees/commits work normally; a brand-new ref just
 *    needs to be created once the first commit exists.
 *  - [RepositoryEmpty] (HTTP 409 "Git Repository is empty."): the repo has
 *    ZERO commits anywhere. Per GitHub's own docs, the Git Database API
 *    (blobs/trees/commits) refuses to operate at all until the repository
 *    is "initialized" — which requires going through the Contents API for
 *    the very first file.
 */
private sealed class RefLookupResult {
    data class Found(val ref: GitRefDto) : RefLookupResult()
    object BranchMissing : RefLookupResult()
    object RepositoryEmpty : RefLookupResult()
}

class GitSyncRepository(
    private val context: Context,
    tokenStore: TokenStore
) {
    private val api: GitHubApi = NetworkModule.createGitHubApi(context, tokenStore)
    private val db = AppDatabase.getInstance(context)
    private val projectDao = db.projectDao()
    private val fileRecordDao = db.fileRecordDao()
    private val recentFolderDao = db.recentFolderDao()
    val fileRepository = ProjectFileRepository(context)

    fun observeProjects(): Flow<List<ProjectEntity>> = projectDao.observeAll()
    fun observeRecentFolders(): Flow<List<RecentFolderEntity>> = recentFolderDao.observeRecent()
    suspend fun getProject(id: String): ProjectEntity? = projectDao.getById(id)

    suspend fun deleteProject(id: String, folderUri: Uri?) {
        projectDao.deleteById(id)
        fileRecordDao.deleteForProject(id)
        if (folderUri != null) {
            fileRepository.releasePermission(folderUri)
        }
    }

    /**
     * Wipes every locally persisted GitSync project and sync snapshot.
     * Called when a DIFFERENT GitHub account connects than the one last
     * connected here, so one account's projects/repos are never shown to,
     * or mistakenly pushed to, a different account. Recent local folders
     * are left alone — they're just device folder shortcuts with no GitHub
     * account information in them.
     */
    suspend fun clearAllLocalProjectData() {
        val projects = projectDao.getAll()
        projects.forEach { project ->
            try {
                fileRepository.releasePermission(Uri.parse(project.folderUri))
            } catch (e: Exception) {
                // Best-effort; a permission that's already gone is fine to ignore.
            }
        }
        projectDao.clearAll()
        fileRecordDao.clearAll()
    }

    suspend fun recordRecentFolder(treeUri: Uri, scanned: ScannedProject) {
        recentFolderDao.upsert(
            RecentFolderEntity(
                treeUri = treeUri.toString(),
                displayName = scanned.rootDisplayName,
                displayPath = scanned.rootDisplayName,
                fileCount = scanned.files.size,
                sizeBytes = scanned.totalSizeBytes,
                lastUsedAtMillis = System.currentTimeMillis()
            )
        )
    }

    /** Pure local comparison against the last-synced snapshot. No network calls. */
    private data class HashedDiff(
        val addedOrModified: List<Pair<ScannedFile, String>>, // file + freshly computed blob sha
        val deletedPaths: List<String>
    )

    private suspend fun computeHashedDiff(projectId: String, scanned: ScannedProject): HashedDiff {
        val previous = fileRecordDao.getForProject(projectId).associateBy { it.path }
        val currentPaths = scanned.files.map { it.relativePath }.toSet()
        val deletedPaths = previous.keys.filter { it !in currentPaths }

        val addedOrModified = mutableListOf<Pair<ScannedFile, String>>()
        for (file in scanned.files) {
            val prevRecord = previous[file.relativePath]
            if (prevRecord != null && prevRecord.sizeBytes == file.sizeBytes) {
                // Same size: hash to confirm content is actually unchanged.
                val bytes = fileRepository.readFileBytes(file.documentUri, file.relativePath)
                val sha = GitBlobSha.of(bytes)
                if (sha != prevRecord.blobSha) {
                    addedOrModified += file to sha
                }
            } else {
                val bytes = fileRepository.readFileBytes(file.documentUri, file.relativePath)
                val sha = GitBlobSha.of(bytes)
                addedOrModified += file to sha
            }
        }
        return HashedDiff(addedOrModified, deletedPaths)
    }

    /** For display only (Project Detail / Push Changes counts) — does not touch GitHub. */
    suspend fun getDiffSummary(projectId: String, scanned: ScannedProject): DiffSummary {
        val previousPaths = fileRecordDao.getForProject(projectId).map { it.path }.toSet()
        val diff = computeHashedDiff(projectId, scanned)
        val added = diff.addedOrModified.filter { it.first.relativePath !in previousPaths }.map { it.first.relativePath }
        val modified = diff.addedOrModified.filter { it.first.relativePath in previousPaths }.map { it.first.relativePath }
        return DiffSummary(added, modified, diff.deletedPaths)
    }

    /**
     * Looks up `refs/heads/{branch}`, distinguishing "branch missing but
     * repo has commits" (404) from "repository has zero commits at all"
     * (409 "Git Repository is empty."). A 409 with any OTHER message is
     * GitHub's documented signal that "the repository is... unavailable" —
     * i.e. still being provisioned right after creation — which is worth a
     * short, bounded retry (not an indefinite one).
     */
    private suspend fun lookupBranchRef(owner: String, repo: String, branch: String): RefLookupResult {
        var attempt = 0
        while (true) {
            try {
                return RefLookupResult.Found(api.getBranchRef(owner, repo, branch))
            } catch (e: HttpException) {
                when (e.code()) {
                    404 -> return RefLookupResult.BranchMissing
                    409 -> {
                        val body = e.response()?.errorBody()?.string()
                        val isEmptyRepo = body?.contains("empty", ignoreCase = true) == true
                        if (isEmptyRepo) {
                            return RefLookupResult.RepositoryEmpty
                        }
                        // Likely "repository is still being created" — GitHub's own
                        // guidance is this is transient. Retry a few times with a
                        // short backoff, then give up rather than retry forever.
                        attempt++
                        GitHubDiagnostics.logApiError("lookup_branch_ref_retry_$attempt", 409, body)
                        if (attempt >= 3) {
                            throw GitHubException.ServerError()
                        }
                        delay(1200L * attempt)
                    }
                    else -> throw e
                }
            }
        }
    }

    /**
     * First-time upload of a project into [owner]/[repo] on [branch]. Two
     * genuinely different code paths, per GitHub's own documented behavior:
     *
     *  - Repository already has commits (or at least a ref history) even if
     *    THIS branch doesn't exist yet: normal Git Database API flow —
     *    blobs -> tree -> commit (no parent) -> create the new ref.
     *  - Repository has ZERO commits (a truly brand-new repo created with
     *    `auto_init=false`): the Git Database API refuses to create blobs
     *    at all (409 "Git Repository is empty."). GitHub's documented fix
     *    is to bootstrap the repository via the Contents API first (which
     *    creates the branch + an initial commit as a side effect), then
     *    use the normal Git Database API for the remaining files on top of
     *    that commit. This never uses `force=true`.
     */
    suspend fun pushInitial(
        projectId: String,
        scanned: ScannedProject,
        owner: String,
        repo: String,
        branch: String,
        commitMessage: String,
        onProgress: (uploaded: Int, total: Int, uploadedBytes: Long, totalBytes: Long) -> Unit
    ): PushOutcome = runGitHubCall("push_initial") {
        if (scanned.files.isEmpty()) {
            throw IllegalStateException("This project folder has no files to push.")
        }

        when (val lookup = lookupBranchRef(owner, repo, branch)) {
            is RefLookupResult.RepositoryEmpty -> pushIntoEmptyRepository(
                projectId, scanned, owner, repo, branch, commitMessage, onProgress
            )
            is RefLookupResult.BranchMissing -> pushWithBaseline(
                projectId, scanned, owner, repo, branch, commitMessage,
                baseTreeSha = null, parentSha = null, existingRefFound = false, onProgress
            )
            is RefLookupResult.Found -> pushWithBaseline(
                projectId, scanned, owner, repo, branch, commitMessage,
                baseTreeSha = api.getCommit(owner, repo, lookup.ref.refObject.sha).tree.sha,
                parentSha = lookup.ref.refObject.sha,
                existingRefFound = true,
                onProgress
            )
        }
    }

    /** Bootstraps a genuinely empty repository, then pushes the rest of the files on top. */
    private suspend fun pushIntoEmptyRepository(
        projectId: String,
        scanned: ScannedProject,
        owner: String,
        repo: String,
        branch: String,
        commitMessage: String,
        onProgress: (uploaded: Int, total: Int, uploadedBytes: Long, totalBytes: Long) -> Unit
    ): PushOutcome {
        // Bootstrap with the smallest file — keeps this extra round-trip fast.
        // Its own commit message is distinct from the user's, so history
        // reads clearly: a tiny "Initialize repository" commit, then the
        // user's real commit with everything else.
        val bootstrapFile = scanned.files.minByOrNull { it.sizeBytes }!!
        if (bootstrapFile.sizeBytes > GITHUB_MAX_BLOB_BYTES) {
            throw GitHubException.ValidationFailed(
                "Every file in this project is larger than GitHub's 100 MB limit, so the repository can't be initialized."
            )
        }
        val bootstrapBytes = fileRepository.readFileBytes(bootstrapFile.documentUri, bootstrapFile.relativePath)
        val bootstrapBase64 = Base64.encodeToString(bootstrapBytes, Base64.NO_WRAP)
        val bootstrapResult = api.createOrUpdateFileContents(
            owner, repo, encodeGitHubContentPath(bootstrapFile.relativePath),
            CreateOrUpdateFileContentsRequestDto(
                message = "Initialize repository",
                content = bootstrapBase64,
                branch = branch
            )
        )
        val initialCommitSha = bootstrapResult.commit.sha
        onProgress(1, scanned.files.size, bootstrapFile.sizeBytes, scanned.totalSizeBytes)

        val remainingFiles = scanned.files.filter { it.relativePath != bootstrapFile.relativePath }
        val bootstrapRecord = FileRecordEntity(
            projectId, bootstrapFile.relativePath, GitBlobSha.of(bootstrapBytes), bootstrapFile.sizeBytes
        )

        if (remainingFiles.isEmpty()) {
            fileRecordDao.replaceSnapshot(projectId, listOf(bootstrapRecord))
            return PushOutcome(initialCommitSha, emptyList())
        }

        val remainingScanned = ScannedProject(
            rootDisplayName = scanned.rootDisplayName,
            files = remainingFiles,
            totalSizeBytes = remainingFiles.sumOf { it.sizeBytes },
            previewItems = scanned.previewItems
        )

        val baseTreeSha = api.getCommit(owner, repo, initialCommitSha).tree.sha
        val outcome = pushWithBaseline(
            projectId, remainingScanned, owner, repo, branch, commitMessage,
            baseTreeSha = baseTreeSha,
            parentSha = initialCommitSha,
            existingRefFound = true,
            onProgress = { uploaded, total, uploadedBytes, totalBytes ->
                onProgress(uploaded + 1, total + 1, uploadedBytes + bootstrapFile.sizeBytes, totalBytes + bootstrapFile.sizeBytes)
            }
        )

        // pushWithBaseline already replaced the snapshot for remainingFiles;
        // merge the bootstrap file's record back in so future diffs know
        // about it too.
        fileRecordDao.upsertAll(listOf(bootstrapRecord))
        return outcome
    }

    /** Normal blob -> tree -> commit -> ref flow, given a known (possibly absent) baseline. */
    private suspend fun pushWithBaseline(
        projectId: String,
        scanned: ScannedProject,
        owner: String,
        repo: String,
        branch: String,
        commitMessage: String,
        baseTreeSha: String?,
        parentSha: String?,
        existingRefFound: Boolean,
        onProgress: (uploaded: Int, total: Int, uploadedBytes: Long, totalBytes: Long) -> Unit
    ): PushOutcome {
        val treeEntries = mutableListOf<TreeEntryDto>()
        val newRecords = mutableListOf<FileRecordEntity>()
        val skipped = mutableListOf<String>()
        var uploadedBytes = 0L
        val total = scanned.files.size
        val totalBytes = scanned.totalSizeBytes

        scanned.files.forEachIndexed { index, file ->
            if (file.sizeBytes > GITHUB_MAX_BLOB_BYTES) {
                skipped += file.relativePath
            } else {
                val bytes = fileRepository.readFileBytes(file.documentUri, file.relativePath)
                val blobSha = GitBlobSha.of(bytes)
                val created = api.createBlob(owner, repo, CreateBlobRequestDto(Base64.encodeToString(bytes, Base64.NO_WRAP)))
                treeEntries += TreeEntryDto(path = file.relativePath, mode = "100644", type = "blob", sha = created.sha)
                newRecords += FileRecordEntity(projectId, file.relativePath, blobSha, file.sizeBytes)
                uploadedBytes += file.sizeBytes
            }
            onProgress(index + 1, total, uploadedBytes, totalBytes)
        }

        val newTree = api.createTree(owner, repo, CreateTreeRequestDto(baseTreeSha, treeEntries))
        val parents = if (parentSha != null) listOf(parentSha) else emptyList()
        val commit = api.createCommit(owner, repo, CreateCommitRequestDto(commitMessage, newTree.sha, parents))

        if (existingRefFound) {
            api.updateBranchRef(owner, repo, branch, UpdateRefRequestDto(commit.sha))
        } else {
            api.createRef(owner, repo, CreateRefRequestDto("refs/heads/$branch", commit.sha))
        }

        fileRecordDao.replaceSnapshot(projectId, newRecords)
        return PushOutcome(commit.sha, skipped)
    }

    /**
     * Push Changes: only blobs for added/modified files are created; deleted
     * files are removed from the tree by supplying a null sha. Returns null
     * when there is genuinely nothing to push (caller should show the
     * existing "No Changes" state and must NOT create an empty commit).
     */
    suspend fun pushChanges(
        projectId: String,
        scanned: ScannedProject,
        owner: String,
        repo: String,
        branch: String,
        commitMessage: String,
        onProgress: (uploaded: Int, total: Int, uploadedBytes: Long, totalBytes: Long) -> Unit
    ): PushOutcome? = runGitHubCall("push_changes") {
        val diff = computeHashedDiff(projectId, scanned)
        if (diff.addedOrModified.isEmpty() && diff.deletedPaths.isEmpty()) return@runGitHubCall null

        val ref = api.getBranchRef(owner, repo, branch)
        val baseTreeSha = api.getCommit(owner, repo, ref.refObject.sha).tree.sha

        val treeEntries = mutableListOf<TreeEntryDto>()
        val updatedRecords = mutableListOf<FileRecordEntity>()
        val skipped = mutableListOf<String>()
        var uploadedBytes = 0L
        val total = diff.addedOrModified.size
        val totalBytes = diff.addedOrModified.sumOf { it.first.sizeBytes }

        diff.addedOrModified.forEachIndexed { index, (file, sha) ->
            if (file.sizeBytes > GITHUB_MAX_BLOB_BYTES) {
                skipped += file.relativePath
            } else {
                val bytes = fileRepository.readFileBytes(file.documentUri, file.relativePath)
                val created = api.createBlob(owner, repo, CreateBlobRequestDto(Base64.encodeToString(bytes, Base64.NO_WRAP)))
                treeEntries += TreeEntryDto(path = file.relativePath, mode = "100644", type = "blob", sha = created.sha)
                updatedRecords += FileRecordEntity(projectId, file.relativePath, sha, file.sizeBytes)
                uploadedBytes += file.sizeBytes
            }
            onProgress(index + 1, total, uploadedBytes, totalBytes)
        }
        diff.deletedPaths.forEach { path ->
            treeEntries += TreeEntryDto(path = path, mode = "100644", type = "blob", sha = null)
        }

        if (treeEntries.isEmpty()) return@runGitHubCall null

        val newTree = api.createTree(owner, repo, CreateTreeRequestDto(baseTreeSha, treeEntries))
        val commit = api.createCommit(owner, repo, CreateCommitRequestDto(commitMessage, newTree.sha, listOf(ref.refObject.sha)))
        api.updateBranchRef(owner, repo, branch, UpdateRefRequestDto(commit.sha))

        if (diff.deletedPaths.isNotEmpty()) {
            fileRecordDao.deleteByPaths(projectId, diff.deletedPaths)
        }
        if (updatedRecords.isNotEmpty()) {
            fileRecordDao.upsertAll(updatedRecords)
        }

        PushOutcome(commit.sha, skipped)
    }

    suspend fun saveProject(project: ProjectEntity) {
        projectDao.upsert(project)
    }
}

/** Percent-encodes each path segment for the Contents API while preserving literal "/". */
private fun encodeGitHubContentPath(path: String): String =
    path.split("/").joinToString("/") { segment -> Uri.encode(segment) }
