package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A folder the user has previously picked with the system folder picker
 * (Storage Access Framework). Lets "Browse folders" show real recent
 * folders instead of a hardcoded demo list. The persisted permission for
 * [treeUri] must still be valid (see [android.content.ContentResolver.persistedUriPermissions])
 * for the folder to be reusable.
 */
@Entity(tableName = "recent_folders")
data class RecentFolderEntity(
    @PrimaryKey val treeUri: String,
    val displayName: String,
    val displayPath: String,
    val fileCount: Int,
    val sizeBytes: Long,
    val lastUsedAtMillis: Long
)
