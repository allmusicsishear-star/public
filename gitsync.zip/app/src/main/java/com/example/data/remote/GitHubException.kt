package com.example.data.remote

/** Errors from the GitHub REST / Git Database API. */
sealed class GitHubException(message: String) : Exception(message) {
    class NoInternet : GitHubException("No internet connection. Check your network and try again.")
    class Unauthorized : GitHubException("Your GitHub session has expired. Please reconnect your account.")
    class RateLimited(resetInSeconds: Long?) : GitHubException(
        if (resetInSeconds != null && resetInSeconds > 0) {
            "GitHub API rate limit reached. Try again in ${resetInSeconds / 60 + 1} minute(s)."
        } else {
            "GitHub API rate limit reached. Please try again shortly."
        }
    )
    class PermissionDenied(
        detail: String?,
        acceptedPermissions: String? = null,
        requestId: String? = null
    ) : GitHubException(
        buildString {
            append(detail?.takeIf { it.isNotBlank() } ?: "GitHub denied permission for this action.")
            if (!acceptedPermissions.isNullOrBlank()) {
                append(" GitHub says this action requires: ")
                append(acceptedPermissions)
                append(".")
            }
            append(" Check that the GitHub App is installed on this account with that permission granted.")
            if (!requestId.isNullOrBlank()) {
                append(" (GitHub request ID: ")
                append(requestId)
                append(")")
            }
        }
    )
    class RepositoryNotFound : GitHubException("That repository could not be found.")
    class ValidationFailed(detail: String?) : GitHubException(
        detail ?: "GitHub rejected the request. Double-check the repository name and try again."
    )
    class BranchConflict : GitHubException("The branch changed on GitHub since your last sync. Pull the latest changes and try again.")
    class ServerError : GitHubException("GitHub is having trouble right now. Please try again shortly.")
    class Unknown(detail: String?) : GitHubException(detail ?: "Something went wrong talking to GitHub.")
}

/** Errors from the OAuth Device Flow specifically. */
sealed class DeviceFlowException(message: String) : Exception(message) {
    class ExpiredToken : DeviceFlowException("This sign-in code expired. Please try connecting again.")
    class AccessDenied : DeviceFlowException("GitHub access was denied.")
    class NoInternet : DeviceFlowException("No internet connection. Check your network and try again.")
    class Other(detail: String?) : DeviceFlowException(detail ?: "Couldn't connect to GitHub. Please try again.")
}
