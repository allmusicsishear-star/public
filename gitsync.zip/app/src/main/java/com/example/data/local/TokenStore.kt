package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the GitHub access token (and a couple of small, non-sensitive account
 * fields used to restore the UI instantly on app start) using an
 * EncryptedSharedPreferences file whose encryption key lives in the Android
 * Keystore.
 *
 * The token NEVER touches plain SharedPreferences, is never logged, and is
 * wiped completely on [clear] (called from Disconnect GitHub).
 */
class TokenStore(context: Context) {

    private val appContext = context.applicationContext

    private val prefs: SharedPreferences by lazy { buildEncryptedPrefs() }

    private fun buildEncryptedPrefs(): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                appContext,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // If the Keystore-backed file is corrupted (e.g. after a Keystore
            // reset on some OEM ROMs) drop it and start clean rather than
            // crashing the app on every launch. We deliberately do not log
            // the exception message, as some OEM implementations include
            // partial key material in it.
            Log.w(TAG, "Recreating encrypted token store after failure")
            appContext.deleteSharedPreferences(PREFS_FILE_NAME)
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
    }

    fun saveAccessToken(token: String) {
        prefs.edit().putString(KEY_ACCESS_TOKEN, token).apply()
    }

    fun getAccessToken(): String? = prefs.getString(KEY_ACCESS_TOKEN, null)

    fun hasAccessToken(): Boolean = !getAccessToken().isNullOrBlank()

    fun saveRefreshToken(token: String) {
        prefs.edit().putString(KEY_REFRESH_TOKEN, token).apply()
    }

    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH_TOKEN, null)

    /**
     * The Client ID of the GitHub App that issued the currently stored
     * token. A GitHub App user-access-token is only meaningful for the
     * specific App (and its installation/permissions) that minted it — it
     * is not portable across GitHub Apps. Recording this lets us detect a
     * token left over from a previous/old GitHub App (e.g. after rotating
     * Client IDs during development) and refuse to reuse it.
     */
    fun saveClientId(clientId: String) {
        prefs.edit().putString(KEY_CLIENT_ID, clientId).apply()
    }

    fun getStoredClientId(): String? = prefs.getString(KEY_CLIENT_ID, null)

    /**
     * The GitHub login (not sensitive — just a username) that was connected
     * last time. Used only to detect an account switch, so per-account
     * local data (Projects, sync snapshots) isn't mixed between accounts.
     */
    fun saveUsername(login: String) {
        prefs.edit().putString(KEY_USERNAME, login).apply()
    }

    fun getStoredUsername(): String? = prefs.getString(KEY_USERNAME, null)

    /** Removes the token and all cached account fields. Called on Disconnect. */
    fun clear() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val TAG = "TokenStore"
        private const val PREFS_FILE_NAME = "gitsync_secure_prefs"
        private const val KEY_ACCESS_TOKEN = "github_access_token"
        private const val KEY_REFRESH_TOKEN = "github_refresh_token"
        private const val KEY_CLIENT_ID = "github_client_id"
        private const val KEY_USERNAME = "github_username"
    }
}
