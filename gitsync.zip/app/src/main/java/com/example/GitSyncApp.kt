package com.example

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BrowseFoldersBottomSheet
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.ReviewChangesBottomSheet
import com.example.ui.navigation.AppScreen
import com.example.ui.navigation.BottomTab
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.ChooseRepoScreen
import com.example.ui.screens.ConnectGitHubScreen
import com.example.ui.screens.CreateRepoScreen
import com.example.ui.screens.ErrorScreen
import com.example.ui.screens.ExistingRepoScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NoChangesScreen
import com.example.ui.screens.ProjectDetailScreen
import com.example.ui.screens.ProjectReadyScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.PushChangesScreen
import com.example.ui.screens.PushSuccessScreen
import com.example.ui.screens.ReviewPushScreen
import com.example.ui.screens.SelectProjectScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UploadProgressScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.screens.WhyGitHubAccessDialog
import com.example.ui.theme.GitGreenLight
import com.example.ui.theme.GitGreenPrimary
import com.example.viewmodel.GitSyncViewModel
import com.example.viewmodel.RepoSelectionMode

@Composable
fun GitSyncApp(
    viewModel: GitSyncViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // Opens a real URL in the device's browser. Used for GitHub's device-flow
    // verification page and for "Open Repository" / "Open in GitHub" actions
    // — there is no simulated/fake browser anywhere in this app.
    val openUrl: (String) -> Unit = remember(context) {
        { url ->
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(context, "No browser app found to open this link.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Real Storage Access Framework folder picker. No broad storage
    // permission is requested anywhere in this app.
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onFolderPicked(uri)
        }
    }

    // Re-checks GitHub App installation state when the app resumes (e.g.
    // returning from the browser after visiting the install page). This
    // never assumes installation succeeded just because onResume fired —
    // it re-verifies through the real GitHub API (see checkInstallationStatus()).
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnResume = rememberUpdatedState { viewModel.onAppResumed() }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                currentOnResume.value()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val showBottomBar = when (uiState.currentScreen) {
        AppScreen.Home,
        AppScreen.Projects,
        AppScreen.Activity,
        AppScreen.Settings -> true
        else -> false
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    modifier = Modifier.testTag("main_bottom_nav_bar")
                ) {
                    // Home
                    NavigationBarItem(
                        selected = uiState.currentTab == BottomTab.HOME,
                        onClick = { viewModel.selectTab(BottomTab.HOME) },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == BottomTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Home") },
                        colors = navBarItemColors(),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    // Projects
                    NavigationBarItem(
                        selected = uiState.currentTab == BottomTab.PROJECTS,
                        onClick = { viewModel.selectTab(BottomTab.PROJECTS) },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == BottomTab.PROJECTS) Icons.Filled.Folder else Icons.Outlined.Folder,
                                contentDescription = "Projects"
                            )
                        },
                        label = { Text("Projects") },
                        colors = navBarItemColors(),
                        modifier = Modifier.testTag("nav_tab_projects")
                    )

                    // Activity
                    NavigationBarItem(
                        selected = uiState.currentTab == BottomTab.ACTIVITY,
                        onClick = { viewModel.selectTab(BottomTab.ACTIVITY) },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == BottomTab.ACTIVITY) Icons.Filled.History else Icons.Outlined.History,
                                contentDescription = "Activity"
                            )
                        },
                        label = { Text("Activity") },
                        colors = navBarItemColors(),
                        modifier = Modifier.testTag("nav_tab_activity")
                    )

                    // Settings
                    NavigationBarItem(
                        selected = uiState.currentTab == BottomTab.SETTINGS,
                        onClick = { viewModel.selectTab(BottomTab.SETTINGS) },
                        icon = {
                            Icon(
                                imageVector = if (uiState.currentTab == BottomTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                contentDescription = "Settings"
                            )
                        },
                        label = { Text("Settings") },
                        colors = navBarItemColors(),
                        modifier = Modifier.testTag("nav_tab_settings")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = uiState.currentScreen) {
                // SCREEN 1: Welcome / Onboarding
                is AppScreen.Welcome -> {
                    WelcomeScreen(
                        onConnectGitHubClick = { viewModel.navigateTo(AppScreen.ConnectGitHub) },
                        onWhyAccessClick = { viewModel.toggleWhyGitHubAccessDialog(true) }
                    )
                }

                // SCREEN 2: Connect GitHub (real OAuth Device Flow)
                is AppScreen.ConnectGitHub -> {
                    ConnectGitHubScreen(
                        account = uiState.account,
                        authStatus = uiState.authStatus,
                        deviceUserCode = uiState.deviceUserCode,
                        deviceVerificationUri = uiState.deviceVerificationUri,
                        installationStatus = uiState.installationStatus,
                        isCheckingInstallation = uiState.isCheckingInstallation,
                        onConnectClick = { viewModel.connectGitHub() },
                        onOpenVerificationUrl = {
                            uiState.deviceVerificationUri?.let { openUrl(it) }
                        },
                        onCancelConnecting = { viewModel.cancelConnecting() },
                        onInstallClick = { openUrl(viewModel.openInstallGitHubApp()) },
                        onCheckInstallationAgainClick = { viewModel.checkInstallationStatus() },
                        onDisconnectClick = { viewModel.requestDisconnect() },
                        onBackClick = { viewModel.navigateTo(AppScreen.Home) }
                    )
                }

                // SCREEN 3: Home Dashboard
                is AppScreen.Home -> {
                    HomeScreen(
                        projects = uiState.projects,
                        accountInitial = uiState.account.avatarInitials,
                        onSelectProjectClick = { viewModel.navigateTo(AppScreen.SelectProject) },
                        onProjectClick = { proj -> viewModel.navigateTo(AppScreen.ProjectDetail(proj.id)) },
                        onViewAllProjectsClick = { viewModel.selectTab(BottomTab.PROJECTS) },
                        onAccountClick = { viewModel.navigateTo(AppScreen.ConnectGitHub) }
                    )
                }

                // SCREEN 4: Select Project
                is AppScreen.SelectProject -> {
                    SelectProjectScreen(
                        selectedFolder = uiState.selectedFolder,
                        onBrowseFoldersClick = { viewModel.openBrowseFolders() },
                        onContinueClick = { viewModel.navigateTo(AppScreen.ProjectReady) },
                        onBackClick = { viewModel.selectTab(BottomTab.HOME) }
                    )
                }

                // SCREEN 5: Project Ready
                is AppScreen.ProjectReady -> {
                    ProjectReadyScreen(
                        projectName = uiState.wizardProjectName,
                        localFolder = uiState.selectedFolder?.relativePath ?: uiState.wizardProjectName,
                        fileCount = uiState.totalFilesCount,
                        sizeMb = uiState.totalSizeMb,
                        files = uiState.previewFiles,
                        branch = uiState.wizardBranch,
                        commitMessage = uiState.wizardCommitMessage,
                        onCommitMessageChange = { viewModel.updateWizardCommitMessage(it) },
                        onContinueClick = { viewModel.navigateTo(AppScreen.ChooseRepo) },
                        onBackClick = { viewModel.navigateTo(AppScreen.SelectProject) }
                    )
                }

                // SCREEN 6: Choose Repository
                is AppScreen.ChooseRepo -> {
                    ChooseRepoScreen(
                        selectedMode = uiState.wizardRepoMode,
                        onSelectMode = { viewModel.setRepoSelectionMode(it) },
                        onContinueClick = {
                            if (uiState.wizardRepoMode == RepoSelectionMode.CREATE_NEW) {
                                viewModel.navigateTo(AppScreen.CreateRepo)
                            } else {
                                viewModel.openExistingRepoScreen()
                            }
                        },
                        onBackClick = { viewModel.navigateTo(AppScreen.ProjectReady) }
                    )
                }

                // SCREEN 7: Create Repository (creates a real GitHub repo)
                is AppScreen.CreateRepo -> {
                    CreateRepoScreen(
                        repoName = uiState.wizardNewRepoName,
                        repoDescription = uiState.wizardNewRepoDesc,
                        isPrivate = uiState.wizardNewRepoPrivate,
                        onRepoNameChange = { viewModel.updateNewRepoFields(it, uiState.wizardNewRepoDesc, uiState.wizardNewRepoPrivate) },
                        onDescriptionChange = { viewModel.updateNewRepoFields(uiState.wizardNewRepoName, it, uiState.wizardNewRepoPrivate) },
                        onVisibilityChange = { viewModel.updateNewRepoFields(uiState.wizardNewRepoName, uiState.wizardNewRepoDesc, it) },
                        onCreateAndContinueClick = { viewModel.createRepository() },
                        onBackClick = { viewModel.navigateTo(AppScreen.ChooseRepo) }
                    )
                }

                // SCREEN 8: Existing Repository (real repo list from GitHub)
                is AppScreen.ExistingRepo -> {
                    ExistingRepoScreen(
                        repos = uiState.remoteRepos,
                        searchQuery = uiState.repoSearchQuery,
                        selectedRepo = uiState.wizardSelectedExistingRepo,
                        onSearchChange = { viewModel.updateRepoSearch(it) },
                        onSelectRepo = { viewModel.selectExistingRepo(it) },
                        onContinueClick = { viewModel.navigateTo(AppScreen.ReviewPush) },
                        onBackClick = { viewModel.navigateTo(AppScreen.ChooseRepo) }
                    )
                }

                // SCREEN 9: Review Before Push
                is AppScreen.ReviewPush -> {
                    val repoFullName = uiState.wizardSelectedExistingRepo?.fullName ?: ""

                    ReviewPushScreen(
                        projectName = uiState.wizardProjectName,
                        repoFullName = repoFullName,
                        branch = uiState.wizardBranch,
                        fileCount = uiState.totalFilesCount,
                        sizeMb = uiState.totalSizeMb,
                        commitMessage = uiState.wizardCommitMessage,
                        onPushClick = { viewModel.startUploadFlow() },
                        onBackClick = {
                            if (uiState.wizardRepoMode == RepoSelectionMode.CREATE_NEW) {
                                viewModel.navigateTo(AppScreen.CreateRepo)
                            } else {
                                viewModel.navigateTo(AppScreen.ExistingRepo)
                            }
                        }
                    )
                }

                // SCREEN 10: Upload / Push Progress (driven by real GitHub API calls)
                is AppScreen.UploadProgress -> {
                    UploadProgressScreen(
                        currentStageIndex = uiState.uploadStageIndex,
                        uploadedFiles = uiState.uploadedFilesCount,
                        totalFiles = uiState.totalFilesCount,
                        progressPercent = uiState.uploadProgressPercent,
                        totalSizeMb = uiState.totalSizeMb
                    )
                }

                // SCREEN 11: Push Success
                is AppScreen.PushSuccess -> {
                    PushSuccessScreen(
                        projectName = uiState.wizardProjectName,
                        repoFullName = uiState.activePushRepoFullName,
                        fileCount = uiState.totalFilesCount,
                        commitMessage = uiState.wizardCommitMessage,
                        onOpenRepoClick = { openUrl("https://github.com/${uiState.activePushRepoFullName}") },
                        onDoneClick = { viewModel.selectTab(BottomTab.HOME) }
                    )
                }

                // SCREEN 12: Project Details / Synced Project
                is AppScreen.ProjectDetail -> {
                    val project = uiState.projects.find { it.id == screen.projectId } ?: uiState.projects.firstOrNull()
                    if (project != null) {
                        ProjectDetailScreen(
                            project = project,
                            onPushChangesClick = { viewModel.openPushChanges(project.id) },
                            onOpenGitHubClick = { openUrl("https://github.com/${project.repoFullName}") },
                            onRemoveProjectClick = { viewModel.requestRemoveProject(project) },
                            onBackClick = { viewModel.selectTab(BottomTab.PROJECTS) }
                        )
                    }
                }

                // SCREEN 13: Push Changes (real diff against the last synced snapshot)
                is AppScreen.PushChanges -> {
                    val project = uiState.projects.find { it.id == screen.projectId } ?: uiState.projects.firstOrNull()
                    if (project != null) {
                        PushChangesScreen(
                            projectName = project.name,
                            changedFiles = uiState.pendingDiffModified,
                            addedFiles = uiState.pendingDiffAdded,
                            deletedFiles = uiState.pendingDiffDeleted,
                            commitMessage = uiState.pushChangesCommitMessage,
                            onCommitMessageChange = { viewModel.updatePushChangesCommitMessage(it) },
                            onReviewChangesClick = { viewModel.toggleReviewChangesSheet(true) },
                            onPushChangesClick = { viewModel.confirmPushChanges(project.id) },
                            onBackClick = { viewModel.navigateTo(AppScreen.ProjectDetail(project.id)) }
                        )
                    }
                }

                // SCREEN 14: No Changes
                is AppScreen.NoChanges -> {
                    val project = uiState.projects.find { it.id == screen.projectId } ?: uiState.projects.firstOrNull()
                    if (project != null) {
                        NoChangesScreen(
                            projectName = project.name,
                            lastPushedTime = project.lastPushedText,
                            onDoneClick = { viewModel.navigateTo(AppScreen.ProjectDetail(project.id)) },
                            onBackClick = { viewModel.navigateTo(AppScreen.ProjectDetail(project.id)) }
                        )
                    }
                }

                // SCREEN 15: Activity
                is AppScreen.Activity -> {
                    ActivityScreen(activities = uiState.activities)
                }

                // SCREEN 16: Projects (with search & real empty state)
                is AppScreen.Projects -> {
                    ProjectsScreen(
                        projects = uiState.projects,
                        searchQuery = uiState.projectSearchQuery,
                        onSearchChange = { viewModel.updateProjectSearch(it) },
                        onProjectClick = { proj -> viewModel.navigateTo(AppScreen.ProjectDetail(proj.id)) },
                        onAddProjectClick = { viewModel.navigateTo(AppScreen.SelectProject) }
                    )
                }

                // SCREEN 17: Settings
                is AppScreen.Settings -> {
                    SettingsScreen(
                        account = uiState.account,
                        defaultBranch = uiState.defaultBranch,
                        defaultVisibilityPrivate = uiState.defaultRepoPrivate,
                        appearance = uiState.appearance,
                        onManageAccountClick = { viewModel.navigateTo(AppScreen.ConnectGitHub) },
                        onTriggerDisconnectClick = { viewModel.requestDisconnect() }
                    )
                }

                // SCREEN 19: Error State (shared by every real failure: auth, repo list/create, folder read, push)
                is AppScreen.ErrorState -> {
                    ErrorScreen(
                        title = screen.title,
                        description = screen.message,
                        onTryAgainClick = { viewModel.retryFromError() },
                        onCancelClick = { viewModel.selectTab(BottomTab.HOME) }
                    )
                }
            }
        }
    }

    // SCREEN 18: Disconnect Confirmation Dialog
    if (uiState.showDisconnectDialog) {
        ConfirmationDialog(
            title = "Disconnect GitHub?",
            message = "Your saved projects will remain on this device, but you won't be able to push changes until you reconnect.",
            confirmButtonText = "Disconnect",
            onConfirm = { viewModel.confirmDisconnect() },
            onDismiss = { viewModel.dismissDisconnectDialog() },
            isDestructive = true,
            testTag = "dialog_disconnect"
        )
    }

    // SCREEN 21: Delete / Remove Project Dialog
    if (uiState.showRemoveProjectDialog) {
        ConfirmationDialog(
            title = "Remove project?",
            message = "This only removes the project from this app. Your GitHub repository will not be deleted.",
            confirmButtonText = "Remove",
            onConfirm = { viewModel.confirmRemoveProject() },
            onDismiss = { viewModel.dismissRemoveProjectDialog() },
            isDestructive = true,
            testTag = "dialog_remove_project"
        )
    }

    // Permission Explainer Dialog
    if (uiState.showWhyGitHubAccessDialog) {
        WhyGitHubAccessDialog(
            onDismiss = { viewModel.toggleWhyGitHubAccessDialog(false) }
        )
    }

    // Browse Folders Bottom Sheet (real recent folders + real system folder picker)
    if (uiState.showBrowseFoldersSheet) {
        BrowseFoldersBottomSheet(
            folders = uiState.recentFolders,
            onSelectFolder = { viewModel.selectFolder(it) },
            onPickNewFolder = {
                viewModel.dismissBrowseFolders()
                folderPickerLauncher.launch(null)
            },
            onDismiss = { viewModel.dismissBrowseFolders() }
        )
    }

    // Review Changes Bottom Sheet (real diff, computed from the last synced snapshot)
    if (uiState.showReviewChangesSheet) {
        ReviewChangesBottomSheet(
            changedFiles = uiState.pendingChangedFileItems,
            onDismiss = { viewModel.toggleReviewChangesSheet(false) }
        )
    }
}

@Composable
private fun navBarItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = GitGreenPrimary,
    selectedTextColor = GitGreenPrimary,
    indicatorColor = GitGreenLight,
    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
)
