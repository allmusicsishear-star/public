package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.selection.SelectionContainer
import com.example.data.DeviceAuthStatus
import com.example.data.GitHubAccount
import com.example.data.InstallationStatus
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.GitHubAvatarView
import com.example.ui.components.GitSyncTopBar
import com.example.ui.components.PrimaryActionButton
import com.example.ui.components.SecondaryActionButton
import com.example.ui.components.SubtleCard
import androidx.compose.material3.CircularProgressIndicator
import com.example.ui.theme.CharcoalTextPrimary
import com.example.ui.theme.CharcoalTextSecondary
import com.example.ui.theme.GitGreenContainer
import com.example.ui.theme.GitGreenLight
import com.example.ui.theme.GitGreenPrimary
import com.example.ui.theme.GitHubDark
import com.example.ui.theme.StatusSyncedGreen
import com.example.ui.theme.SubtleBorderLight

@Composable
fun WelcomeScreen(
    onConnectGitHubClick: () -> Unit,
    onWhyAccessClick: () -> Unit
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 28.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            // Minimalist Logo & Visual Node
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(GitGreenLight)
                        .border(1.dp, GitGreenContainer, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "GitSync Logo",
                        tint = GitGreenPrimary,
                        modifier = Modifier.size(42.dp)
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Title & Subtitle
                Text(
                    text = "GitHub, without the terminal.",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Upload and sync your project directly from your phone.",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                Spacer(modifier = Modifier.height(36.dp))

                // Minimalist Developer Flow Badge
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        FlowStepTag("Select Project")
                        Text("→", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FlowStepTag("Choose Repo")
                        Text("→", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FlowStepTag("Push")
                    }
                }
            }

            // Bottom Actions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                PrimaryActionButton(
                    text = "Connect GitHub",
                    onClick = onConnectGitHubClick,
                    testTag = "welcome_connect_github_button"
                )

                Spacer(modifier = Modifier.height(14.dp))

                TextButton(
                    onClick = onWhyAccessClick,
                    modifier = Modifier.testTag("welcome_why_access_button")
                ) {
                    Text(
                        text = "Why do I need GitHub access?",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun FlowStepTag(label: String) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        ),
        color = MaterialTheme.colorScheme.onBackground
    )
}

@Composable
fun ConnectGitHubScreen(
    account: GitHubAccount,
    authStatus: DeviceAuthStatus = DeviceAuthStatus.DISCONNECTED,
    deviceUserCode: String? = null,
    deviceVerificationUri: String? = null,
    installationStatus: InstallationStatus = InstallationStatus.UNKNOWN,
    isCheckingInstallation: Boolean = false,
    onConnectClick: () -> Unit,
    onOpenVerificationUrl: () -> Unit = {},
    onCancelConnecting: () -> Unit = {},
    onInstallClick: () -> Unit = {},
    onCheckInstallationAgainClick: () -> Unit = {},
    onDisconnectClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Scaffold(
        topBar = {
            GitSyncTopBar(
                title = "Connect GitHub",
                onBackClick = onBackClick
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Connect your GitHub account to upload and sync your projects.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Main Connection Card
            SubtleCard(testTag = "github_connection_card") {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (account.isConnected) {
                        // Connected State
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            GitHubAvatarView(
                                initials = account.avatarInitials,
                                sizeDp = 48
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "@${account.username}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(StatusSyncedGreen)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Connected",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = StatusSyncedGreen,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        SecondaryActionButton(
                            text = "Disconnect",
                            onClick = onDisconnectClick,
                            testTag = "github_disconnect_button"
                        )
                    } else if (authStatus != DeviceAuthStatus.DISCONNECTED) {
                        // Device Flow in progress: show the real code + URL from GitHub.
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            CircularProgressIndicator(color = GitGreenPrimary, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = when (authStatus) {
                                    DeviceAuthStatus.REQUESTING_CODE -> "Requesting a sign-in code from GitHub…"
                                    DeviceAuthStatus.AWAITING_USER -> "Enter this code on GitHub to finish connecting"
                                    else -> "Connecting…"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            if (authStatus == DeviceAuthStatus.AWAITING_USER && deviceUserCode != null) {
                                Spacer(modifier = Modifier.height(16.dp))
                                SelectionContainer {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = GitGreenLight,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, GitGreenContainer)
                                    ) {
                                        Text(
                                            text = deviceUserCode,
                                            style = MaterialTheme.typography.headlineSmall.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.SemiBold,
                                                letterSpacing = 4.sp
                                            ),
                                            color = GitGreenPrimary,
                                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = deviceVerificationUri ?: "github.com/login/device",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                SecondaryActionButton(
                                    text = "Open in Browser",
                                    onClick = onOpenVerificationUrl,
                                    testTag = "github_open_verification_url_button"
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            TextButton(
                                onClick = onCancelConnecting,
                                modifier = Modifier.testTag("github_cancel_connect_button")
                            ) {
                                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        // Disconnected State
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "GitHub account",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Not connected",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        PrimaryActionButton(
                            text = "Connect GitHub",
                            onClick = onConnectClick,
                            testTag = "github_connect_button"
                        )
                    }
                }
            }

            // GitHub App installation is a separate state from GitHub
            // authorization above — shown only once the account is
            // connected, and only until installation is confirmed.
            if (account.isConnected && installationStatus != InstallationStatus.INSTALLED) {
                Spacer(modifier = Modifier.height(16.dp))
                SubtleCard(testTag = "install_github_app_card") {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Install GitSync Mobile",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "One more step: install GitSync Mobile on your GitHub account to create repositories and sync files.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        if (isCheckingInstallation) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(color = GitGreenPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Checking installation…",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            PrimaryActionButton(
                                text = "Install GitSync",
                                onClick = onInstallClick,
                                testTag = "install_github_app_button"
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = onCheckInstallationAgainClick,
                                modifier = Modifier.testTag("check_installation_again_button")
                            ) {
                                Text(
                                    text = "Check again",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Privacy helper note
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Your GitHub account is used only to access repositories you choose.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun WhyGitHubAccessDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Why do I need GitHub access?",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onBackground
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "GitSync allows you to upload local Android projects to GitHub without needing Termux or command line tools.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "• Repository Access: To create repositories and push your code.\n" +
                            "• Zero File Scraping: Your code remains on your phone until you initiate a push.\n" +
                            "• Secure Token: Tokens are stored locally on your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("why_access_ok_button")
            ) {
                Text("Got it", color = GitGreenPrimary)
            }
        },
        shape = RoundedCornerShape(14.dp),
        containerColor = MaterialTheme.colorScheme.surface
    )
}
