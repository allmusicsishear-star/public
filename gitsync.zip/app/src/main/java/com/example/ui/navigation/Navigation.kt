package com.example.ui.navigation

sealed class AppScreen {
    object Welcome : AppScreen()
    object ConnectGitHub : AppScreen()
    object Home : AppScreen()
    object Projects : AppScreen()
    object Activity : AppScreen()
    object Settings : AppScreen()
    
    // Upload Wizard
    object SelectProject : AppScreen()
    object ProjectReady : AppScreen()
    object ChooseRepo : AppScreen()
    object CreateRepo : AppScreen()
    object ExistingRepo : AppScreen()
    object ReviewPush : AppScreen()
    object UploadProgress : AppScreen()
    object PushSuccess : AppScreen()
    
    // Project Management
    data class ProjectDetail(val projectId: String) : AppScreen()
    data class PushChanges(val projectId: String) : AppScreen()
    data class NoChanges(val projectId: String) : AppScreen()
    data class ErrorState(val message: String, val title: String = "Something went wrong", val canRetry: Boolean = true) : AppScreen()
}

enum class BottomTab {
    HOME,
    PROJECTS,
    ACTIVITY,
    SETTINGS
}
