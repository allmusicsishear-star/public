package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Muted natural green primary action colors
val GitGreenPrimary = Color(0xFF2E7D32)
val GitGreenHover = Color(0xFF256629)
val GitGreenLight = Color(0xFFE8F5E9)
val GitGreenContainer = Color(0xFFDCF0DC)

// Charcoal and neutral shades
val CharcoalTextPrimary = Color(0xFF1F2328)
val CharcoalTextSecondary = Color(0xFF57606A)
val CharcoalTextTertiary = Color(0xFF8C959F)

// Backgrounds & Surfaces (Light)
val NeutralBackgroundLight = Color(0xFFF9F9F8)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceLightVariant = Color(0xFFF3F4F6)
val SubtleBorderLight = Color(0xFFE1E4E8)

// Dark Theme counterparts
val DarkBackground = Color(0xFF0F1113)
val DarkSurface = Color(0xFF171A1E)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkTextPrimary = Color(0xFFE6EDF3)
val DarkTextSecondary = Color(0xFF8B949E)
val DarkBorder = Color(0xFF30363D)
val DarkGreenContainer = Color(0xFF193321)

// Status & Accent
val StatusSyncedGreen = Color(0xFF2E7D32)
val StatusPendingOrange = Color(0xFFB45309)
val StatusErrorRed = Color(0xFFC53030)
val StatusErrorBg = Color(0xFFFDE8E8)
val GitHubDark = Color(0xFF24292F)

