# GitSync — Prototype → Real App Conversion Report

The existing Compose UI (screens, navigation, theme, layout, colors) was **not**
changed except where real functionality required a small, additive UI element
(noted below). No screens were redesigned, replaced, or restyled.

## 1. Files changed

**Deleted**
- `app/src/main/java/com/example/data/MockData.kt`

**New — data layer**
- `data/local/TokenStore.kt` — Keystore-backed encrypted token storage
- `data/local/ProjectEntity.kt`, `FileRecordEntity.kt`, `RecentFolderEntity.kt`, `Daos.kt`, `AppDatabase.kt` — Room persistence
- `data/remote/GitHubDtos.kt`, `GitHubApi.kt`, `NetworkModule.kt`, `GitHubException.kt` — Device Flow + REST/Git Database API (Retrofit/Moshi/OkHttp)
- `data/repository/GitHubAuthRepository.kt`, `GitHubRepoRepository.kt`, `ProjectFileRepository.kt`, `GitSyncRepository.kt`, `GitHubErrorMapping.kt`, `LocalFileException.kt`
- `data/util/GitIgnoreMatcher.kt`, `GitBlobSha.kt`

**Rewritten**
- `viewmodel/GitSyncViewModel.kt` — now an `AndroidViewModel`, wired to all repositories above
- `GitSyncApp.kt` — real SAF launcher, real browser `Intent`s, updated call sites

**Edited**
- `data/Models.kt` — added `DeviceAuthStatus`; removed the hardcoded `"suhail"` / 18-repo defaults and the dead `PushStage` type
- `ui/screens/WelcomeAndAuthScreens.kt` — removed the "sample projects" guest button; added the device-code/verification-URL UI to `ConnectGitHubScreen` (same cards/buttons/typography as the rest of the screen)
- `ui/screens/SettingsAndErrorScreens.kt` — removed the "DEMO SIMULATION" section
- `ui/screens/ProjectsAndActivityScreens.kt` — removed the "Show sample / Demo empty" toggle
- `ui/screens/HomeScreen.kt` — real account initial instead of hardcoded `"S"`; the "2 projects synced today" line now reflects the real project count
- `ui/components/CommonComponents.kt` — `BrowseFoldersBottomSheet` now opens the real system folder picker and lists real recent folders instead of a hardcoded list; `SimulatedBrowserDialog` deleted entirely
- `ui/navigation/Navigation.kt` — `ErrorState` gained a `title` field so the one existing error screen can represent every real failure (auth, repo list/create, folder read, push) instead of a hardcoded "Couldn't push changes"
- `AndroidManifest.xml` — added `INTERNET` / `ACCESS_NETWORK_STATE` (missing before; the app made no network calls)
- `gradle/libs.versions.toml`, `app/build.gradle.kts` — added `androidx.security:security-crypto` and `androidx.documentfile:documentfile`. Retrofit, Moshi (+ KSP codegen), OkHttp, Room (+ KSP), and coroutines were **already present** and unused — nothing else was added.

## 2. Mock/demo functionality removed

`MockData.kt` and every reference to it; the fake GitHub account/avatar/username; hardcoded repos (Customer, Smart Scanner, Pocket Arcade) and their fake file/size/activity numbers; `FolderCandidate`/`candidateFolders` hardcoded list; `simulatedUrlToOpen` + `SimulatedBrowserDialog`; all `delay()`-based fake progress/stage simulation; the "Show sample / Demo empty" projects toggle; the "Demo Error State" settings button; the "Explore dashboard with sample projects" guest shortcut; the hardcoded `"Smart Scanner" → No Changes` special case.

## 3. GitHub authentication

Real OAuth **Device Flow for a GitHub App** (`GitHubAuthRepository`):
`POST github.com/login/device/code` → shows the real `user_code` + `verification_uri` on the existing Connect screen → polls `POST github.com/login/oauth/access_token` honoring `authorization_pending` / `slow_down` / `expired_token` / `access_denied` → stores the resulting access token (and refresh token, if the App has expiring tokens enabled) → fetches `GET /user`. No PAT, no Client Secret, no callback server, no Firebase/Supabase. Sensitive values are never logged (a custom `HttpLoggingInterceptor` level guards this, and the auth interceptor only attaches the Bearer token to `api.github.com` requests).

## 4. Repository API implementation

`GitHubRepoRepository` lists all accessible repos (paginated) and creates new ones via `POST /user/repos` (`auto_init=false`, since the app performs the first commit itself).

## 5. Folder picker

`ActivityResultContracts.OpenDocumentTree()`, launched from `GitSyncApp.kt`. Permission is persisted via `takePersistableUriPermission` and re-verified on every reopen (`hasPersistedPermission`). No broad storage permission is requested anywhere.

## 6. Initial upload implementation

`GitSyncRepository.pushInitial` uses the Git Database API directly: reads each file, computes a git-compatible blob SHA, `POST .../git/blobs`, builds one flat tree (`POST .../git/trees`, using full relative paths — GitHub builds the nested structure), `POST .../git/commits`, then either `PATCH` an existing branch ref or `POST` a new one (handles pushing into a brand-new empty repo). Files over GitHub's 100 MB blob limit are skipped and reported, never silently truncated.

## 7. Push Changes implementation

Local diffing (`computeHashedDiff`) compares a fresh scan's blob SHAs against the SHAs recorded after the last successful push (stored per-file in Room). Only added/modified files get new blobs; deleted files are removed by submitting a tree entry with `sha: null`; the new tree is built with `base_tree` = current commit's tree, so unrelated files are carried forward untouched. If nothing changed, no API calls are made and no commit is created — the real "No Changes" screen is shown.

## 8. Local project persistence

Room (`ProjectEntity` + `FileRecordEntity` + `RecentFolderEntity`). Reopening a project after an app restart re-verifies folder permission, rescans, and diffs against the stored snapshot before allowing Push Changes.

## 9. Security / storage implementation

Access (and refresh) tokens live in `EncryptedSharedPreferences` backed by an AES-256-GCM Android Keystore key (`TokenStore`), never in plain `SharedPreferences`, never logged. Disconnect wipes the store completely.

## 10. Remaining limitations

- **Build not verified by me** — this sandbox has no Android SDK / access to `dl.google.com`, so I could not run `./gradlew build` myself. I did trace every call site by hand (see §11) but you should treat the first local build as the real compile check.
- `.gitignore` support only reads the **root** `.gitignore` (not per-subfolder ones) and supports the common subset of patterns (wildcards, `**`, negation, anchoring, dir-only) rather than the full git spec.
- The Activity feed is session-only (resets on app restart); only Projects and their sync state persist. Extending it to Room would be a small, separate addition.
- Avatars show the real account's initial (not a fetched photo) — no image-loading library was added since none existed in the project and the existing `GitHubAvatarView` only renders initials.
- A SAF folder's "recent folder" display path is its name, not a real filesystem path (SAF generally doesn't expose one across storage providers).
- Token refresh is implemented for GitHub Apps with expiring tokens enabled, but isn't automatically retried mid-request on a 401 yet — a 401 currently disconnects the account and asks the user to reconnect.

## 11. Steps to test

1. Open the project in Android Studio (this environment couldn't run Gradle — Android Studio needs internet access to `dl.google.com`/Maven Central, which is blocked here).
2. Sync Gradle — it will pull `androidx.security:security-crypto` and `androidx.documentfile:documentfile`, the only two new dependencies.
3. Build & run on a device/emulator with API 24+.
4. **Connect GitHub**: tap Connect → real device code + `github.com/login/device` shown → open it (in a browser, on any device) → enter the code → app polls and lands on Home with your real username/repo count.
5. **Push a new project**: Select Project → "Choose a folder from your device" → pick a real folder → see real file/size counts → Create Repo (creates a real GitHub repo) or pick an existing one you can push to → Review → Push → watch real upload progress → Push Success → "Open Repository" opens the real repo in your browser.
6. **Verify on GitHub.com** that the repo now contains your files with the correct structure and the commit message you typed.
7. Edit/add/delete a file in the local folder, then from the app: Project → Push Changes → confirm the counts match what you changed → Push. Verify the new commit on GitHub only touches those files.
8. Push again with no local changes → should land on the real "No Changes" screen with no new commit created.
9. Kill and reopen the app → project should still be listed (Room) and pushable (re-verifies folder permission).
10. Settings → Disconnect → confirm the app returns to Connect GitHub and the token is gone (re-launch the app; it should not auto-reconnect).

## 12. Build result (original conversion)

Not run in this sandbox — no Android SDK / no access to `dl.google.com`. All files were hand-checked for import correctness, matching constructor/DTO field names, and brace/paren balance.

## 13. Update — "Resource not accessible by integration" (403 on Create Repository, previous turn)

### Root cause (confirmed by reading the actual stored code, not assumed)
`TokenStore` had no concept of *which* GitHub App issued the token it was holding — it only tracked whether a token existed (`hasAccessToken()`), and `GitHubAuthRepository.isConnected()` returned `true` for any non-blank stored token. During earlier testing under the OLD GitHub App (Client ID `Iv23lil2VVUAgPgCNYYy`, App ID `5037781`), a real user-access-token was minted and saved to the encrypted store. When the `GITHUB_APP_CLIENT_ID` constant was changed to the new App's Client ID, **that old token was never invalidated** — the app kept treating the device as "connected" and kept attaching the *old app's* token to every `api.github.com` request, including `POST /user/repos`. GitHub checks a token's permissions against the App that issued it, not against whatever Client ID happens to be compiled into the client today, so every Create Repository call was authorized as the *old* App — which evidently lacked effective `Administration: write` (or wasn't installed with a scope that permits creating new repos) — hence `403 Resource not accessible by integration`. This is a stale-session bug, not an endpoint bug and not a missing-permission bug in the new App's configuration.

The token-attachment mechanism itself (`NetworkModule`'s auth interceptor) was verified correct: it reads `tokenStore.getAccessToken()` fresh on every request and attaches `Authorization: Bearer <token>` only to `api.github.com` — so once the *right* token is stored, it reaches every request without any additional fix needed there.

### Exact files changed this turn
- `data/local/TokenStore.kt` — added `saveClientId(clientId)` / `getStoredClientId()`, backed by a new `KEY_CLIENT_ID` entry in the same encrypted store.
- `data/repository/GitHubAuthRepository.kt` — `isConnected()` now compares the stored token's Client ID against the repository's current `clientId`; a mismatch (including "none recorded," which covers any pre-existing token from before this fix) clears the store and reports not-connected, forcing a fresh Device Flow authorization. `pollForAccessToken` now calls `tokenStore.saveClientId(clientId)` in the same step it saves a freshly issued token, so every future token is tagged with the App that actually issued it.
- `viewmodel/GitSyncViewModel.kt` — `GITHUB_APP_CLIENT_ID` changed from `Iv23lil2VVUAgPgCNYYy` to `Iv23liBov1aMzInMTttP`. This is the only place the Client ID is defined; confirmed by project-wide search that no other file references either the old Client ID or the old App ID (`5037781`).
- `data/remote/GitHubException.kt` — `PermissionDenied` now takes optional `acceptedPermissions` and `requestId` and folds them into the message.
- `data/repository/GitHubErrorMapping.kt` — on a non-rate-limited 403, now reads `X-Accepted-GitHub-Permissions` and `X-GitHub-Request-Id` from the response headers (in addition to the `X-RateLimit-Remaining` / `X-RateLimit-Reset` pair already used to detect rate limiting) and passes them into `PermissionDenied`, alongside GitHub's own `message` field parsed from the JSON error body (already preserved verbatim before this change — the "Resource not accessible by integration" text you saw was always GitHub's real message, not a generic string).

No UI file needed to change: `ErrorScreen` already renders whatever string is passed as `description`, so the richer 403 message flows through automatically.

### Direct answers
- **Was the old token/session the problem?** Yes — confirmed root cause. Fixed by client-ID-tagged session validation in `TokenStore` / `GitHubAuthRepository`.
- **Is the new Client ID wired everywhere?** Yes — it's a single constant (`GITHUB_APP_CLIENT_ID`) used by both `requestDeviceCode` and `pollAccessToken`; verified no other occurrence of the old Client ID or old App ID anywhere in the project.
- **Is the resulting token actually attached to requests?** Yes, verified — the interceptor reads the token at request time (not cached) and attaches it only to `api.github.com` calls.
- **Are the new App's permissions being detected correctly?** The app now guarantees it will use a token that was actually issued *by the new App* (rather than reusing the old one), and it now surfaces GitHub's own `X-Accepted-GitHub-Permissions` header verbatim in the error text if a 403 still occurs — so "detection" is as accurate as GitHub's own response. This app has no way to *inspect* the App's configured permissions ahead of time (that's not exposed via the user-access-token flow); it can only react to what GitHub says on each call.
- **Is Create Repository now functional?** The code-level bug (stale cross-app token reuse) is fixed and `POST /user/repos` was already correctly implemented. I could not execute this against live GitHub from this sandbox (no network access to GitHub, no Android runtime) — see "Remaining issue" below.
- **Remaining issue to rule out on your end:** `POST /user/repos` (creating a *new* repo) requires the GitHub App installation to have access to **all repositories**, not "Only select repositories" — a not-yet-created repo can't be individually selected during install. If you installed/authorized the new App with "Only select repositories," Create Repository will still 403 even with correct permissions and a fresh token, and the app will now show you that exact GitHub message plus `X-Accepted-GitHub-Permissions` so you can confirm this from the error text itself. Disconnect and reconnect once (to force the new Device Flow authorization) and check the app's installation scope on `github.com/settings/installations` if the error persists.

## 14. Update — persistent 403 with `repository_creation=write` reported missing

### Exact root cause

This is **not a code bug** — every part of the auth/request pipeline was re-verified and is correct (see checklist below). GitHub's own error text is the actual answer:

> "GitHub says this action requires: `administration=write; repository_creation=write`"

`repository_creation` is a **real, separate GitHub App permission** from `administration` — GitHub is telling you the App is missing a second, distinct grant, not that `administration` itself is wrong. I confirmed against current (2025) GitHub community reports that this is a well-known, current platform behavior: **a GitHub App's user-access-token generally cannot create repositories in a user's *personal* (non-organization) account at all** — `POST /user/repos` for a personal namespace is fundamentally restricted for GitHub App tokens regardless of which repository permissions the App has, because "Administration" is a *repository-level* permission (it only ever applies to a repo that already exists and that the installation already has access to) and repo creation in a personal account isn't gated by anything a GitHub App can be granted in the same way it can for an organization (`POST /orgs/{org}/repos`, which *does* work with an installation that has `administration: write` and "All repositories" access). This matches exactly what your screenshot shows: GitHub explicitly names a second permission (`repository_creation`) it needs and can't get satisfied for a personal account through this endpoint/token combination.

### Verification checklist (your items 1–6), confirmed by re-reading the code

| # | Check | Result |
|---|---|---|
| 1 | Token type | **User Access Token only.** The codebase has zero calls to `POST /app/installations/{id}/access_tokens` or any installation-token endpoint — `GitHubAuthRepository` only ever obtains a token via the Device Flow (`login/device/code` → `login/oauth/access_token`). |
| 2 | Fresh under current Client ID | Yes — enforced by the `isConnected()` fix from the previous turn: any token not tagged with `Iv23liBov1aMzInMTttP` is discarded and a fresh Device Flow run is forced. |
| 3 | Token's effective permissions | Not independently introspectable from this client (GitHub doesn't expose a "what can this user-token do" endpoint) — the app can only observe what GitHub reports per-request, which is now fully surfaced (see below). |
| 4 | Exact `POST /user/repos` request | Confirmed in `GitHubApi.kt` / `GitHubRepoRepository.kt` — unchanged, correct, sends `name`, `description`, `private`, `auto_init=false`. |
| 5 | `Authorization: Bearer <token>` | Confirmed in `NetworkModule`'s interceptor — attached only to `api.github.com`, read fresh from `TokenStore` on every request. |
| 6 | No installation token used for `POST /user/repos` | Confirmed — there is no installation-token code path in this app at all. |

### Exact files changed this turn
- **New: `data/remote/GitHubDiagnostics.kt`** — temporary diagnostic logger. Logs *only* HTTP status, GitHub's JSON `message`, `X-Accepted-GitHub-Permissions`, `X-GitHub-Request-Id`, and the current GitHub username (`Log.w`, tag `GitSyncDiag`). Never logs the access token, refresh token, device code, user code, or Client ID/Secret.
- **`data/repository/GitHubAuthRepository.kt`** — `fetchAuthenticatedUser()` now sets `GitHubDiagnostics.currentUsername` right after a successful `GET /user`.
- **`data/repository/GitHubErrorMapping.kt`** — the 403 branch now calls `GitHubDiagnostics.log403(...)` with the four header/message values before building the exception. No other logic changed.

No UI file was touched.

### Direct answers
- **Was it a stale/wrong token, wrong Client ID, or wrong attached token?** No — all three were re-checked and are correct as of the previous fix.
- **Is `Administration: write` being detected correctly?** Yes — GitHub is actively evaluating it (that's why it lists it back to you); the App does have it. The blocker is the *second*, separate permission GitHub is also asking for.
- **Is Create Repository functional now?** Not for a **personal-account** target with this token/endpoint combination — that appears to be a platform-level restriction, not something this code change can fix. It should already work (or can be made to work) for an **organization** you install the App into, using `POST /orgs/{org}/repos` with the same user-access-token, since organization repo creation is the case GitHub Apps are actually designed to support with `administration: write`.
- **Recommended next step (no code guess involved):** open the GitHub App's settings → Permissions & events, and check whether "Repository creation" appears as its own grantable permission anywhere in the list (it may be listed as read-only informational, or may simply not be grantable for personal-account targets at all). If your real goal is "push a personal Android project to a personal GitHub account," the officially supported path is a **user access token from an OAuth App (not a GitHub App)**, or a **fine-grained Personal Access Token**, for the create-repo call specifically — GitHub Apps are the supported path for everything *after* the repo exists (Contents, pushing commits, etc.), which is exactly why Device Flow + your current permissions already work correctly for the push/pull side of this app.


## 15. Update — Empty-repo push bug fix, GitHub App installation flow, and second-account diagnosis

### A. Root cause of the empty-repository first-push bug (confirmed via GitHub's own docs)

`pushInitial` looked up `refs/heads/{branch}` and only treated **HTTP 404** as "no ref yet, proceed as a fresh repo." But GitHub's Git Database API has a documented, different behavior for a truly brand-new repository (zero commits ever, which is exactly what `auto_init=false` produces): it returns **HTTP 409 "Git Repository is empty."** for `GET .../git/ref/...` — and, per GitHub's own docs, for `POST .../git/blobs` too. My code re-threw any non-404 error, so this 409 propagated up and was mapped (correctly, for a *different* real scenario) to `GitHubException.BranchConflict()` — producing exactly the "The branch changed on GitHub since your last sync" message you saw, even though nothing had ever been pushed.

I verified this against GitHub's own official guidance before changing anything: *"The REST API will return a 409 Conflict if the Git repository is empty... For an empty repository, you can use the `PUT /repos/{owner}/{repo}/contents/{path}` endpoint to create content and initialize the repository."*

### B. How the empty-repository initial push was fixed

`GitSyncRepository.lookupBranchRef` (private) now distinguishes three real states instead of two:
- **404** → `BranchMissing`: repo has commits, just not this branch — unchanged, existing blob→tree→commit→**create**Ref flow.
- **409 with "empty" in the message** → `RepositoryEmpty`: genuinely zero commits. Handled by the new `pushIntoEmptyRepository`: the smallest project file is written via the Contents API (`PUT .../contents/{path}`, message "Initialize repository"), which creates the branch and a first commit as a side effect with **no parent**. Every remaining file is then pushed through the normal Git Database API (blobs → tree with `base_tree` = that first commit's tree → commit → **update**Ref), so the result is one small bootstrap commit followed by one commit containing your actual project and commit message — never a `force` update.
- **409 with any other message** → treated as GitHub's documented "repository temporarily unavailable" case (still provisioning) and retried up to 3 times with a short backoff, then fails clearly rather than looping forever.
- **Found** → repo already has this branch: unchanged, existing update-in-place flow using the real current commit SHA as parent/base tree.

I also found and fixed a second, related bug while re-verifying "G — remote branch changed" against GitHub's actual docs: a non-fast-forward `PATCH .../git/refs/{ref}` (someone else pushed in between) is a **422** ("Update is not a fast forward"), not a 409. It was falling into the generic validation-error bucket instead of the intended conflict message. `mapHttpException` now recognizes that specific 422 text and routes it to the same `BranchConflict` message/UI as before — so genuine remote-changed conflicts still show the existing conflict screen, and are no longer confused with the empty-repo case.

### C. Second-account findings — root cause, confirmed by code + GitHub's own responses

**Problem 2 (push → 403 "contents=write" required) is the clean, confirmable one:** this account's installation of GitSync Mobile doesn't have Contents: write approved (or the App isn't installed on it at all). This is squarely "GitHub App installation" being separate from "GitHub user authorization" — the second account completed Device Flow (authorization) fine, but that alone never implied installation/permission. This is now handled two ways: proactively (the new Install card, driven by a real `GET /user/installations` check) and reactively (a friendlier "GitHub permission required" message with the real GitHub detail underneath, routing back to the Connect screen).

**Problem 1 ("Repository creation failed.", a 422) is less certain without a live retest**, but the evidence points the same direction as the earlier "administration=write; repository_creation=write" finding for the app's own account: creating a repo in a *personal* GitHub namespace via a GitHub App's user-access-token is, per current GitHub documentation and multiple corroborating developer reports, restricted regardless of the App's configured permissions. I could not find an official GitHub statement that this is *impossible* in 100% of cases (only strong, consistent secondary evidence), so I've made the 422 error path surface GitHub's `errors[]` sub-array (which GitHub often omits from the top-level `message` but includes for the real reason) instead of just the generic top-level text — the next real attempt will show the actual underlying reason instead of just "Repository creation failed." I did not — and could not, from this sandbox — invent a code fix for a platform-level restriction; see the Remaining Limitations section.

I confirmed via code re-inspection (not assumption) that this is unrelated to stale tokens, wrong Client ID, or wrong token attachment — all three were already fixed/verified in earlier turns, and adding a second, genuinely different GitHub account is itself proof those mechanisms work (a stale-token bug would fail identically for every account, not manifest as new, different, account-specific 403/422s).

### D. How GitHub App installation detection works

`GitHubAuthRepository.checkInstallation()` calls the GitHub-documented `GET /user/installations` ("List app installations accessible to the user access token") with the current Bearer user-access-token — no invented endpoint, no PAT. It matches the returned installations by **App slug** (`gitsync-mobile`, from the public install URL) rather than by App ID or any personal identifier, so this works identically for any GitHub user. For a match, it reads the installation's own `permissions.contents` / `permissions.administration` and only reports `INSTALLED` if both are `"write"`; otherwise (or if no matching installation exists) it reports `NOT_INSTALLED`. Any network/API failure reports `UNKNOWN` rather than guessing — this is never a locally-trusted boolean; every check re-asks GitHub.

### E. How the Install card appears/disappears

New `InstallationStatus` (`UNKNOWN` / `NOT_INSTALLED` / `INSTALLED`) is tracked in `GitSyncUiState`, separately from `DeviceAuthStatus`/`GitHubAccount.isConnected` (authorization). The card (added to the *existing* `ConnectGitHubScreen`, using its existing `SubtleCard`/`PrimaryActionButton`/`TextButton` components — no new visual style) shows whenever `account.isConnected && installationStatus != INSTALLED`. It appears automatically right after a successful Device Flow authorization (the screen now stays on Connect GitHub instead of jumping to Home when installation isn't confirmed yet) and on every app resume (`ON_RESUME`, via a `DisposableEffect`/`LifecycleEventObserver` in `GitSyncApp.kt`) while not yet installed — covering the "user installs it, comes back from the browser" case without any deep-link plumbing. "Install GitSync" opens `https://github.com/apps/gitsync-mobile` via a plain `Intent.ACTION_VIEW` (no WebView). "Check again" re-runs the same real API check on demand. The card never disappears just because the browser was opened — only a fresh `GET /user/installations` reporting both permissions as `write` hides it.

### F. How account switching was made safe

`TokenStore` now also remembers the *username* (not just the token/Client ID) tied to the current session. `GitHubAuthRepository.didAccountChange(newLogin)` compares that to whatever a fresh Device Flow just authenticated as; if they differ, `GitSyncViewModel.connectGitHub()` calls the new `GitSyncRepository.clearAllLocalProjectData()` (wipes the `projects` and `file_records` Room tables and releases their SAF folder permissions) **before** showing the new account's state. Disconnecting alone still preserves projects (unchanged, existing behavior/copy) — only connecting as a *different* login triggers the wipe, so re-connecting the *same* account later still sees its own projects.

### Files changed this turn
- `data/local/TokenStore.kt` — added username tracking.
- `data/repository/GitHubAuthRepository.kt` — `checkInstallation()`, `didAccountChange()`/`rememberUsername()`, `GITHUB_APP_SLUG`/`GITHUB_APP_INSTALL_URL`.
- `data/remote/GitHubDiagnostics.kt` — generalized to `logApiError(action, ...)` for any failing call, not just 403s.
- `data/repository/GitHubErrorMapping.kt` — action-tagged logging on every mapped error; 422 sub-error parsing; 422 "not a fast forward" now correctly maps to the conflict message.
- `data/repository/GitHubRepoRepository.kt` — `runGitHubCall` call sites now pass an action label.
- `data/repository/GitSyncRepository.kt` — `lookupBranchRef` (empty-repo/branch-missing/found distinction + bounded retry), `pushIntoEmptyRepository` (Contents API bootstrap), `pushWithBaseline` (shared blob/tree/commit/ref logic), `clearAllLocalProjectData()`.
- `data/local/Daos.kt` — `FileRecordDao.clearAll()`.
- `data/remote/GitHubDtos.kt` — DTOs for `GET /user/installations` and the Contents API bootstrap call; `GitHubApiErrorDto` gained the `errors[]` sub-array.
- `data/remote/GitHubApi.kt` — `listUserInstallations()`, `createOrUpdateFileContents()`.
- `data/Models.kt` — `InstallationStatus` enum.
- `viewmodel/GitSyncViewModel.kt` — installation state, `checkInstallationStatus()`, `onAppResumed()`, `openInstallGitHubApp()`, account-switch wiring in `connectGitHub()`, friendlier permission-error handling (`showPermissionRequiredError`) in create-repo/push/push-changes.
- `GitSyncApp.kt` — `ConnectGitHubScreen` wiring for the new params; `DisposableEffect` lifecycle observer for resume-triggered re-checks.
- `ui/screens/WelcomeAndAuthScreens.kt` — the Install card added to the existing Connect screen, using only existing components.

### Confirmations
- **No PAT / password / private key / Client Secret introduced anywhere** — Device Flow + user-access-token remains the only auth mechanism; `checkInstallation()` reuses the same Bearer token.
- **No mock/demo/simulated GitHub functionality reintroduced** — swept the whole `com.example` tree for `mock`/`simulat`/`fake`/`demo`/`sample`; nothing found beyond this report's own prose.
- **No `force=true`** anywhere in the ref-update calls — both call sites use the default `force=false`.
- **Existing frontend preserved** — no screen was redesigned, no navigation restructured, no colors/typography/existing components changed. The only additions are the Install card (built from the screen's own existing components) and the lifecycle hook (invisible, no UI).

### Remaining limitations / what could not be live-tested
- **I did not run this against live GitHub** — no network access or Android runtime in this sandbox. Everything above is based on direct code inspection, GitHub's own documented API behavior (verified via search rather than assumed), and hand-tracing every call path — not an executed test run. Please treat TEST 1–11 / TEST A–H as the actual verification checklist.
- Whether **Problem 1 (Create Repository 422 for a second account)** is now actually fixable, or is a hard GitHub-Apps-can't-create-personal-repos platform limitation, is still not 100%-confirmed from here — the improved error message (with GitHub's `errors[]` detail) is what will settle it on your next real attempt.
- The empty-repo fix produces **two commits** for a brand-new repo's first push (a tiny "Initialize repository" commit, then one with your real message and files) — this is a direct, necessary consequence of GitHub refusing Git Database API writes until something exists, not a shortcut.
- `GET /user/installations` reflects installations *of the App on accounts the user administers/owns*; if a user is only a *member* (not admin) of an org where the App is installed, GitHub's own docs note that org's installation may not appear for their personal token — this is a GitHub-side scoping rule, not something this code can work around.


